import requests
import time
from django.core.management.base import BaseCommand
from core.models import Grad


class Command(BaseCommand):
    help = "Geokodira gradove koji nemaju koordinate (Nominatim/OSM)"

    def handle(self, *args, **options):
        gradovi = Grad.objects.filter(latitude__isnull=True)

        for grad in gradovi:
            resp = requests.get(
                "https://nominatim.openstreetmap.org/search",
                params={
                    "q": f"{grad.naziv}, Srbija",
                    "format": "json",
                    "limit": 1,
                },
                headers={"User-Agent": "MojMajstor-studentski-projekat"},  # obavezno, Nominatim traži User-Agent
            ).json()

            if resp:
                grad.latitude = resp[0]["lat"]
                grad.longitude = resp[0]["lon"]
                grad.save()
                self.stdout.write(f"{grad.naziv} -> {resp[0]['lat']}, {resp[0]['lon']}")
            else:
                self.stdout.write(f"Nije pronađeno: {grad.naziv}")

            time.sleep(1)  # Nominatim traži max 1 zahtev u sekundi (fair use policy)