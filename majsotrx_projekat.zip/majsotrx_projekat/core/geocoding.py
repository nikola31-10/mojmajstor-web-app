from decimal import Decimal, InvalidOperation

import requests
from django.conf import settings


class GeocodingServiceError(Exception):
    """Geocoding servis trenutno nije dostupan ili je vratio neispravan odgovor."""


def geocode_address(adresa, grad):
    """Vraća (latitude, longitude) za punu adresu u Srbiji ili None."""
    upit = f"{adresa.strip()}, {grad.strip()}, Srbija"

    try:
        response = requests.get(
            settings.GEOCODING_API_URL,
            params={
                "q": upit,
                "format": "jsonv2",
                "limit": 1,
                "countrycodes": "rs",
                "accept-language": "sr-Latn",
                "addressdetails": 1,
            },
            headers={"User-Agent": settings.GEOCODING_USER_AGENT},
            timeout=(3.05, 8),
        )
        response.raise_for_status()
        rezultati = response.json()
    except (requests.RequestException, ValueError) as exc:
        raise GeocodingServiceError from exc

    if not rezultati:
        return None

    try:
        return Decimal(rezultati[0]["lat"]), Decimal(rezultati[0]["lon"])
    except (KeyError, InvalidOperation, TypeError) as exc:
        raise GeocodingServiceError from exc
