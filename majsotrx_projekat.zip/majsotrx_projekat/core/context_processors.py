from .models import Notifikacija

def broj_neprocitanih(request):
    if request.session.get("idKor"):
        broj = Notifikacija.objects.filter(
            idkor_id=request.session["idKor"],
            procitana=0
        ).count()
    else:
        broj = 0

    return {
        "broj_neprocitanih": broj
    }