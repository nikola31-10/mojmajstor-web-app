from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0002_majstorkategorija_notifikacija_opstina_poruka_and_more"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql=(
                        "ALTER TABLE korisnik "
                        "ADD COLUMN latitude DECIMAL(9,6) NULL, "
                        "ADD COLUMN longitude DECIMAL(9,6) NULL;"
                    ),
                    reverse_sql=(
                        "ALTER TABLE korisnik "
                        "DROP COLUMN latitude, "
                        "DROP COLUMN longitude;"
                    ),
                ),
            ],
            state_operations=[
                migrations.AddField(
                    model_name="korisnik",
                    name="latitude",
                    field=models.DecimalField(
                        max_digits=9,
                        decimal_places=6,
                        blank=True,
                        null=True,
                    ),
                ),
                migrations.AddField(
                    model_name="korisnik",
                    name="longitude",
                    field=models.DecimalField(
                        max_digits=9,
                        decimal_places=6,
                        blank=True,
                        null=True,
                    ),
                ),
            ],
        ),
    ]
