import os
from contextlib import ExitStack, contextmanager, nullcontext
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import django

# Omogućava pokretanje testova i direktno iz PyCharm unittest runnera.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "majstorix.settings")
django.setup()

from django.test import RequestFactory, SimpleTestCase
from django.urls import reverse

from core import views


class TestPrikazaKorisnickogZahteva(SimpleTestCase):
    """Zajednička priprema za funkcionalnosti koje korisnik izvršava na zahtevu."""

    def setUp(self):
        self.factory = RequestFactory()
        self.korisnik = SimpleNamespace(idkor=4)
        self.majstor = SimpleNamespace(
            prosecnaocena=0,
            korisnik=SimpleNamespace(idkor=26),
            save=MagicMock(),
        )
        self.zahtev = SimpleNamespace(
            idzah=52,
            korisnik=self.korisnik,
            korisnik_id=4,
            majstor=self.majstor,
            majstor_id=26,
            status="ZAVRSEN",
        )

    def post_request(self, podaci):
        request = self.factory.post(
            reverse("prikaz_zahteva_korisnika", args=[self.zahtev.idzah]),
            podaci,
        )
        request.session = {"idKor": self.korisnik.idkor}
        return request

    @contextmanager
    def okruzenje_viewa(self):
        aktivni_termini = MagicMock()
        aktivni_termini.order_by.return_value.first.return_value = None

        with (
            patch.object(
                views.Zahtev.objects,
                "select_related",
                return_value=MagicMock(),
            ),
            patch("core.views.get_object_or_404", return_value=self.zahtev),
            patch.object(
                views.Poruka.objects,
                "filter",
                return_value=MagicMock(order_by=MagicMock(return_value=[])),
            ),
            patch.object(
                views.SlikaProblema.objects,
                "filter",
                return_value=MagicMock(order_by=MagicMock(return_value=[])),
            ),
            patch(
                "core.views._aktivni_termini_za_zahtev",
                return_value=aktivni_termini,
            ),
            patch("core.views.messages") as poruke,
        ):
            yield poruke

    def pozovi_view(self, podaci):
        request = self.post_request(podaci)
        return views.prikaz_stranice_zahteva_korisnika(
            request,
            self.zahtev.idzah,
        )


class PrijavaProblemaTests(TestPrikazaKorisnickogZahteva):
    """Testovi slučaja upotrebe prijavljivanja problema na zahtevu."""

    def test_korisnik_moze_da_prijavi_problem(self):
        with self.okruzenje_viewa(), patch.object(
            views.Prijava.objects,
            "create",
        ) as create_prijave:
            response = self.pozovi_view({
                "akcija": "prijava_problema",
                "opis_prijave": "Majstor se nije pojavio u zakazanom terminu.",
            })

        create_prijave.assert_called_once_with(
            korisnik=self.korisnik,
            zahtev=self.zahtev,
            opis="Majstor se nije pojavio u zakazanom terminu.",
            status="POSLATA",
        )
        self.assertEqual(response.status_code, 302)

    def test_prazan_opis_ne_kreira_prijavu(self):
        with self.okruzenje_viewa(), patch.object(
            views.Prijava.objects,
            "create",
        ) as create_prijave:
            self.pozovi_view({
                "akcija": "prijava_problema",
                "opis_prijave": "",
            })

        create_prijave.assert_not_called()


class OcenjivanjeMajstoraTests(TestPrikazaKorisnickogZahteva):
    """Testovi čuvanja ocene i ažuriranja prosečne ocene majstora."""

    def test_ocena_se_cuva_i_azurira_prosek_majstora(self):
        ocena = SimpleNamespace(
            ocena=None,
            komentar=None,
            save=MagicMock(),
        )
        queryset = MagicMock()
        queryset.aggregate.return_value = {"ocena__avg": 5.0}

        with (
            self.okruzenje_viewa(),
            patch.object(
                views.Ocena.objects,
                "get_or_create",
                return_value=(ocena, True),
            ),
            patch.object(
                views.Ocena.objects,
                "filter",
                return_value=queryset,
            ),
        ):
            response = self.pozovi_view({
                "akcija": "sacuvaj_ocenu_komentar",
                "ocena": "5",
                "komentar": "",
            })

        self.assertEqual(ocena.ocena, 5)
        ocena.save.assert_called_once_with()
        self.assertEqual(self.majstor.prosecnaocena, 5.0)
        self.majstor.save.assert_called_once_with()
        self.assertEqual(response.status_code, 302)

    def test_postojeca_ocena_se_ne_menja(self):
        ocena = SimpleNamespace(
            ocena=4,
            komentar=None,
            save=MagicMock(),
        )

        with self.okruzenje_viewa() as poruke, patch.object(
            views.Ocena.objects,
            "get_or_create",
            return_value=(ocena, False),
        ):
            self.pozovi_view({
                "akcija": "sacuvaj_ocenu_komentar",
                "ocena": "2",
                "komentar": "",
            })

        self.assertEqual(ocena.ocena, 4)
        ocena.save.assert_not_called()
        self.majstor.save.assert_not_called()
        poruke.warning.assert_called_once()


class OstavljanjeKomentaraTests(TestPrikazaKorisnickogZahteva):
    """Testovi čuvanja komentara korisnika za izabranog majstora."""

    def test_komentar_se_cuva(self):
        ocena = SimpleNamespace(
            ocena=None,
            komentar=None,
            save=MagicMock(),
        )

        with self.okruzenje_viewa(), patch.object(
            views.Ocena.objects,
            "get_or_create",
            return_value=(ocena, True),
        ):
            response = self.pozovi_view({
                "akcija": "sacuvaj_ocenu_komentar",
                "ocena": "",
                "komentar": "Odličan i veoma profesionalan majstor.",
            })

        self.assertEqual(
            ocena.komentar,
            "Odličan i veoma profesionalan majstor.",
        )
        ocena.save.assert_called_once_with()
        self.majstor.save.assert_not_called()
        self.assertEqual(response.status_code, 302)

    def test_postojeci_komentar_se_ne_menja(self):
        ocena = SimpleNamespace(
            ocena=None,
            komentar="Prvobitni komentar.",
            save=MagicMock(),
        )

        with self.okruzenje_viewa() as poruke, patch.object(
            views.Ocena.objects,
            "get_or_create",
            return_value=(ocena, False),
        ):
            self.pozovi_view({
                "akcija": "sacuvaj_ocenu_komentar",
                "ocena": "",
                "komentar": "Novi komentar.",
            })

        self.assertEqual(ocena.komentar, "Prvobitni komentar.")
        ocena.save.assert_not_called()
        poruke.warning.assert_called_once()


class AdministracijaKorisnikaTests(SimpleTestCase):
    """Testovi administratorskog blokiranja i aktiviranja korisnika."""

    def setUp(self):
        self.factory = RequestFactory()
        self.admin = SimpleNamespace(idulo_id=3)
        self.korisnik = SimpleNamespace(
            idkor=7,
            status="AKTIVAN",
            razlogblokiranja=None,
            save=MagicMock(),
        )

    def pozovi_view(self, podaci):
        request = self.factory.post(
            reverse("administracija_korisnika", args=[self.korisnik.idkor]),
            podaci,
        )
        request.session = {"idKor": 31}

        with patch(
            "core.views.get_object_or_404",
            side_effect=[self.admin, self.korisnik],
        ):
            return views.administracija_korisnika(
                request,
                self.korisnik.idkor,
            )

    def test_administrator_moze_da_blokira_korisnika(self):
        response = self.pozovi_view({
            "akcija": "blokiraj",
            "razlog": "Kršenje pravila korišćenja.",
        })

        self.assertEqual(self.korisnik.status, "BLOKIRAN")
        self.assertEqual(
            self.korisnik.razlogblokiranja,
            "Kršenje pravila korišćenja.",
        )
        self.korisnik.save.assert_called_once_with()
        self.assertEqual(response.status_code, 302)

    def test_administrator_moze_da_aktivira_korisnika(self):
        self.korisnik.status = "BLOKIRAN"
        self.korisnik.razlogblokiranja = "Prethodni razlog."

        response = self.pozovi_view({"akcija": "aktiviraj"})

        self.assertEqual(self.korisnik.status, "AKTIVAN")
        self.assertIsNone(self.korisnik.razlogblokiranja)
        self.korisnik.save.assert_called_once_with()
        self.assertEqual(response.status_code, 302)


class OdobravanjeMajstoraTests(SimpleTestCase):
    """Testovi administratorskog odobravanja i odbijanja majstora."""

    def setUp(self):
        self.factory = RequestFactory()
        self.admin = SimpleNamespace(idulo_id=3)
        self.majstor = SimpleNamespace(
            verifikacija="NA_CEKANJU",
            razlogodbijanja="Stari razlog.",
            save=MagicMock(),
        )

    def pozovi_view(self, podaci):
        request = self.factory.post(
            reverse("lista_zahteva_majstora"),
            podaci,
        )
        request.session = {"idKor": 31}

        with patch(
            "core.views.get_object_or_404",
            side_effect=[self.admin, self.majstor],
        ):
            return views.lista_zahteva_majstora(request)

    def test_administrator_moze_da_odobri_majstora(self):
        response = self.pozovi_view({
            "akcija": "prihvati",
            "idmajstor": "26",
        })

        self.assertEqual(self.majstor.verifikacija, "VERIFIKOVAN")
        self.assertIsNone(self.majstor.razlogodbijanja)
        self.majstor.save.assert_called_once_with()
        self.assertEqual(response.status_code, 302)

    def test_administrator_moze_da_odbije_majstora(self):
        response = self.pozovi_view({
            "akcija": "odbij",
            "idmajstor": "26",
            "razlogOdbijanja": "Dokumentacija nije potpuna.",
        })

        self.assertEqual(self.majstor.verifikacija, "ODBIJEN")
        self.assertEqual(
            self.majstor.razlogodbijanja,
            "Dokumentacija nije potpuna.",
        )
        self.majstor.save.assert_called_once_with()
        self.assertEqual(response.status_code, 302)


class RegistracijaMajstoraTests(SimpleTestCase):
    """Testovi opisa profila i teksta zahteva pri registraciji majstora."""

    def setUp(self):
        self.factory = RequestFactory()
        self.podaci = {
            "ime": "Petar",
            "prezime": "Petrović",
            "email": "petar@example.com",
            "username": "petar_majstor",
            "lozinka": "lozinka123",
            "lozinka2": "lozinka123",
            "telefon": "+381 64 123 4567",
            "adresa": "Knez Mihailova 12",
            "idgra": "1",
            "uloga": "majstor",
            "kategorije": ["2"],
            "opis_majstora": "Profesionalno obavljam molerske i završne radove.",
            "opis_verifikacije": (
                "Imam deset godina iskustva i posedujem potrebnu opremu."
            ),
        }
        self.grad = SimpleNamespace(idgra=1, naziv="Beograd")
        self.uloga = SimpleNamespace(iduloga=2)
        self.kategorija = SimpleNamespace(pk=2)
        self.korisnik = SimpleNamespace(idkor=99)
        self.majstor = SimpleNamespace(pk=99)

    def request(self, podaci=None):
        request = self.factory.post(
            reverse("registracija"),
            podaci or self.podaci,
        )
        request.session = {}
        return request

    @contextmanager
    def osnovni_mockovi(self):
        prazna_lista = MagicMock()
        prazna_lista.order_by.return_value = []

        ne_postoji = MagicMock()
        ne_postoji.exists.return_value = False

        kategorije = MagicMock()
        kategorije.count.return_value = 1
        kategorije.__iter__.return_value = iter([self.kategorija])

        with ExitStack() as stack:
            stack.enter_context(patch.object(
                views.Grad.objects,
                "all",
                return_value=prazna_lista,
            ))
            stack.enter_context(patch.object(
                views.Kategorija.objects,
                "all",
                return_value=prazna_lista,
            ))
            stack.enter_context(patch.object(
                views.Korisnik.objects,
                "filter",
                return_value=ne_postoji,
            ))
            stack.enter_context(patch.object(
                views.Grad.objects,
                "get",
                return_value=self.grad,
            ))
            stack.enter_context(patch.object(
                views.Uloga.objects,
                "get",
                return_value=self.uloga,
            ))
            stack.enter_context(patch.object(
                views.Kategorija.objects,
                "filter",
                return_value=kategorije,
            ))
            yield

    def test_opis_i_tekst_verifikacije_se_cuvaju(self):
        cursor = MagicMock()
        cursor_context = MagicMock()
        cursor_context.__enter__.return_value = cursor
        connection_mock = MagicMock()
        connection_mock.cursor.return_value = cursor_context

        with (
            self.osnovni_mockovi(),
            patch(
                "core.views.geocode_address",
                return_value=(44.8176, 20.4633),
            ),
            patch(
                "core.views.transaction.atomic",
                return_value=nullcontext(),
            ),
            patch.object(
                views.Korisnik.objects,
                "create",
                return_value=self.korisnik,
            ),
            patch.object(
                views.Majstor.objects,
                "create",
                return_value=self.majstor,
            ) as create_majstora,
            patch("core.views.connection", connection_mock),
        ):
            response = views.registracija_view(self.request())

        create_majstora.assert_called_once_with(
            korisnik=self.korisnik,
            prosecnaocena=0,
            opis=self.podaci["opis_majstora"],
            opisverifikacije=self.podaci["opis_verifikacije"],
            verifikacija="NA_CEKANJU",
        )
        cursor.executemany.assert_called_once()
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse("index"))

    def test_tekst_verifikacije_je_obavezan_za_majstora(self):
        podaci = dict(self.podaci)
        podaci["opis_verifikacije"] = ""

        with self.osnovni_mockovi():
            response = views.registracija_view(self.request(podaci))

        self.assertEqual(response.status_code, 200)
        self.assertContains(
            response,
            "Tekst zahteva za odobravanje mora imati najmanje 20 karaktera.",
        )
