from datetime import datetime, time, timedelta
from pathlib import Path
from urllib import request
from uuid import uuid4

from django.conf import settings
from django.contrib.auth import logout
from django.db import transaction
from django.db.models import Avg, Prefetch
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from django.db.models import Avg
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.urls import reverse
from django.utils import timezone
from django.db.models import Q
from openai import OpenAI
from core.models import *
from core.geocoding import GeocodingServiceError, geocode_address


import re

from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.db import connection

#   INDEX, NOTIFIKACIJE, LOGIN i REGISTRACIJA
def index(request):
    """Prikazuje početnu stranicu sa verifikovanim majstorima, gradovima i kategorijama."""

    majstori = (
        Majstor.objects
        .select_related("korisnik", "korisnik__idgra")
        .prefetch_related(
            Prefetch(
                "majstorkategorija_set",
                queryset=MajstorKategorija.objects.select_related("idkat")
            )
        )
        .filter(verifikacija="VERIFIKOVAN")
    )

    gradovi = Grad.objects.all().order_by('naziv')
    kategorije = Kategorija.objects.all().order_by('naziv')

    broj_neprocitanih = Notifikacija.objects.filter(
        idkor_id=request.session.get('idKor'),
        procitana=0
    ).count()

    return render(request, 'core/index.html', {
        'majstori': majstori,
        'gradovi': gradovi,
        'kategorije': kategorije,
        'broj_neprocitanih' : broj_neprocitanih,
    })

def notifikacije_view(request):
    """Prikazuje obaveštenja prijavljenog korisnika i broj nepročitanih obaveštenja."""

    if "idKor" not in request.session:
        return redirect("login")

    id_korisnika = request.session["idKor"]

    notifikacije = Notifikacija.objects.filter(
        idkor_id=id_korisnika
    ).order_by("-idnot")

    broj_neprocitanih = Notifikacija.objects.filter(
        idkor_id=id_korisnika,
        procitana=0
    ).count()

    return render(request, "core/notifikacije.html", {
        "notifikacije": notifikacije,
        "broj_neprocitanih": broj_neprocitanih
    })

def login_view(request):
    """Prijavljuje korisnika, čuva njegove podatke u sesiji i preusmerava ga prema ulozi."""

    if "idKor" in request.session:
        redirect('index')

    if request.method == "POST":

        username = request.POST.get("username")
        lozinka = request.POST.get("lozinka")

        korisnik = Korisnik.objects.filter(
            username=username,
            lozinka=lozinka
        ).first()

        if korisnik:

            request.session["idKor"] = korisnik.idkor
            request.session["ime"] = korisnik.ime
            request.session["prezime"] = korisnik.prezime
            request.session["username"] = korisnik.username
            request.session["tip"] = Uloga.objects.get(iduloga = korisnik.idulo.iduloga).naziv

            if request.session["tip"] == 'ADMIN':
                return redirect("lista_korisnika")

            return redirect("index")

        return render(request,"core/login.html",{"greska": "Pogresno korisnicko ime ili lozinka."})

    return render(request, "core/login.html")

def logout_view(request):
    """Odjavljuje prijavljenog korisnika, briše njegovu sesiju i vraća ga na početnu stranicu."""

    if "idKor" not in request.session:
        return redirect('index')
    logout(request)
    return redirect('index')

def registracija_view(request):
    """Registruje novog korisnika ili majstora nakon validacije podataka i adrese."""

    if "idKor" in request.session:
        return redirect("index")

    gradovi = Grad.objects.all().order_by("naziv")
    kategorije = Kategorija.objects.all().order_by("naziv")

    # Podrazumevane vrednosti za prvo otvaranje stranice.
    uneseni_podaci = {}
    izabrane_kategorije = []
    majstor_izabran = False

    if request.method == "POST":
        uneseni_podaci = request.POST

        ime = request.POST.get("ime", "").strip()
        prezime = request.POST.get("prezime", "").strip()
        email = request.POST.get("email", "").strip()
        username = request.POST.get("username", "").strip()
        lozinka = request.POST.get("lozinka", "")
        lozinka2 = request.POST.get("lozinka2", "")
        telefon = request.POST.get("telefon", "").strip()
        adresa = request.POST.get("adresa", "").strip()
        idgra = request.POST.get("idgra", "").strip()
        izabrana_uloga = request.POST.get("uloga", "").strip()
        opis_majstora = request.POST.get("opis_majstora", "").strip()
        opis_verifikacije = request.POST.get(
            "opis_verifikacije",
            ""
        ).strip()

        majstor_izabran = izabrana_uloga == "majstor"

        # Vrednosti checkboxova stižu kao stringovi,
        # pa ih pretvaramo u cele brojeve.
        izabrane_kategorije = [
            int(id_kategorije)
            for id_kategorije in request.POST.getlist("kategorije")
            if id_kategorije.isdigit()
        ]

        def prikazi_gresku(poruka):
            return render(request, "core/registracija.html", {
                "gradovi": gradovi,
                "kategorije": kategorije,
                "greska": poruka,
                "uneseni_podaci": uneseni_podaci,
                "izabrane_kategorije": izabrane_kategorije,
                "majstor_izabran": majstor_izabran,
            })

        # Provera obaveznih polja
        if not all([
            ime,
            prezime,
            email,
            username,
            lozinka,
            lozinka2,
            telefon,
            adresa,
            idgra,
            izabrana_uloga,
        ]):
            return prikazi_gresku("Sva polja su obavezna.")

        # Provera imena
        if len(ime) < 2 or len(ime) > 45:
            return prikazi_gresku(
                "Ime mora imati između 2 i 45 karaktera."
            )

        if not re.fullmatch(
            r"[A-Za-zČĆŽŠĐčćžšđ\s'-]+",
            ime
        ):
            return prikazi_gresku(
                "Ime sme da sadrži samo slova, razmake, "
                "crticu i apostrof."
            )

        # Provera prezimena
        if len(prezime) < 2 or len(prezime) > 45:
            return prikazi_gresku(
                "Prezime mora imati između 2 i 45 karaktera."
            )

        if not re.fullmatch(
            r"[A-Za-zČĆŽŠĐčćžšđ\s'-]+",
            prezime
        ):
            return prikazi_gresku(
                "Prezime sme da sadrži samo slova, razmake, "
                "crticu i apostrof."
            )

        # Provera email adrese
        try:
            validate_email(email)
        except ValidationError:
            return prikazi_gresku(
                "Email adresa nije ispravna."
            )

        if len(email) > 100:
            return prikazi_gresku(
                "Email adresa je predugačka."
            )

        # Provera username-a
        if len(username) < 4 or len(username) > 45:
            return prikazi_gresku(
                "Username mora imati između 4 i 45 karaktera."
            )

        if not re.fullmatch(r"[A-Za-z0-9_.-]+", username):
            return prikazi_gresku(
                "Username sme da sadrži samo slova, cifre, "
                "tačku, donju crtu i crticu."
            )

        # Provera da li se lozinke poklapaju.
        # Nema provere dužine lozinke.
        if lozinka != lozinka2:
            return prikazi_gresku(
                "Lozinke se ne poklapaju."
            )

        # Provera telefona
        if not re.fullmatch(r"\+?[0-9\s()/-]+", telefon):
            return prikazi_gresku(
                "Broj telefona nije ispravan."
            )

        cifre_telefona = re.sub(r"\D", "", telefon)

        if (
            len(cifre_telefona) < 8
            or len(cifre_telefona) > 15
        ):
            return prikazi_gresku(
                "Broj telefona mora imati između 8 i 15 cifara."
            )

        # Provera adrese
        if len(adresa) < 3 or len(adresa) > 100:
            return prikazi_gresku(
                "Adresa mora imati između 3 i 100 karaktera."
            )

        # Provera jedinstvenosti username-a
        if Korisnik.objects.filter(
            username__iexact=username
        ).exists():
            return prikazi_gresku(
                "Username već postoji."
            )

        # Provera jedinstvenosti email-a
        if Korisnik.objects.filter(
            email__iexact=email
        ).exists():
            return prikazi_gresku(
                "Email već postoji."
            )

        # Provera grada
        try:
            grad = Grad.objects.get(idgra=idgra)
        except (Grad.DoesNotExist, ValueError):
            return prikazi_gresku(
                "Izabrani grad nije ispravan."
            )

        # Provera uloge
        if izabrana_uloga == "majstor":
            id_uloge = 2

            if not izabrane_kategorije:
                return prikazi_gresku(
                    "Majstor mora izabrati najmanje jednu kategoriju."
                )

            if len(opis_majstora) < 10:
                return prikazi_gresku(
                    "Opis usluga majstora mora imati najmanje 10 karaktera."
                )

            if len(opis_majstora) > 500:
                return prikazi_gresku(
                    "Opis usluga majstora može imati najviše 500 karaktera."
                )

            if len(opis_verifikacije) < 20:
                return prikazi_gresku(
                    "Tekst zahteva za odobravanje mora imati najmanje 20 karaktera."
                )

            if len(opis_verifikacije) > 1000:
                return prikazi_gresku(
                    "Tekst zahteva za odobravanje može imati najviše 1000 karaktera."
                )

        elif izabrana_uloga == "korisnik":
            id_uloge = 1
            izabrane_kategorije = []
            opis_majstora = ""
            opis_verifikacije = ""

        else:
            return prikazi_gresku(
                "Izabrana uloga nije ispravna."
            )

        try:
            uloga = Uloga.objects.get(iduloga=id_uloge)
        except Uloga.DoesNotExist:
            return prikazi_gresku(
                "Izabrana uloga ne postoji u bazi."
            )

        # Dohvatanje izabranih kategorija
        kategorije_majstora = Kategorija.objects.filter(
            idkat__in=izabrane_kategorije
        )

        # Provera da korisnik nije poslao nepostojeće ID-jeve.
        if (
            izabrana_uloga == "majstor"
            and kategorije_majstora.count()
            != len(set(izabrane_kategorije))
        ):
            return prikazi_gresku(
                "Jedna ili više izabranih kategorija nisu ispravne."
            )

        # Provera adrese i dohvatanje koordinata
        try:
            koordinate = geocode_address(
                adresa,
                grad.naziv
            )
        except GeocodingServiceError:
            return prikazi_gresku(
                "Trenutno nije moguće proveriti adresu. "
                "Pokušajte ponovo."
            )

        if koordinate is None:
            return prikazi_gresku(
                "Adresa nije pronađena u izabranom gradu. "
                "Proverite ulicu i broj."
            )

        latitude, longitude = koordinate

        # Sve se izvršava kao jedna transakcija.
        with transaction.atomic():
            korisnik = Korisnik.objects.create(
                ime=ime,
                prezime=prezime,
                email=email,
                username=username,
                lozinka=lozinka,
                telefon=telefon,
                adresa=adresa,
                latitude=latitude,
                longitude=longitude,
                idgra=grad,
                idulo=uloga,
                status="AKTIVAN",
            )

            if izabrana_uloga == "majstor":
                majstor = Majstor.objects.create(
                    korisnik=korisnik,
                    prosecnaocena=0,
                    opis=opis_majstora,
                    opisverifikacije=opis_verifikacije,
                    verifikacija="NA_CEKANJU",
                )

                redovi_za_upis = [
                    (majstor.pk, kategorija.pk)
                    for kategorija in kategorije_majstora
                ]

                with connection.cursor() as cursor:
                    cursor.executemany(
                        """
                        INSERT INTO majstor_kategorija
                            (idMajstor, idKat)
                        VALUES (%s, %s)
                        """,
                        redovi_za_upis,
                    )

        return redirect("index")

    return render(request, "core/registracija.html", {
        "gradovi": gradovi,
        "kategorije": kategorije,
        "uneseni_podaci": uneseni_podaci,
        "izabrane_kategorije": izabrane_kategorije,
        "majstor_izabran": majstor_izabran,
    })


#   PROCES ZAHTEVA KORISNIKA
def profil_majstora(request, idKor):
    """Prikazuje javni profil izabranog majstora sa njegovim podacima i kategorijama usluga."""

    majstor = Majstor.objects.select_related(
        "korisnik",
        "korisnik__idgra"
    ).get(pk=idKor)

    kategorije = (
        Kategorija.objects
        .filter(zahtev__majstor=majstor)
        .distinct()
    )

    return render(request, "core/profilMajstora.html", {
        "majstor": majstor,
        "kategorije": kategorije,
    })

def kreiranje_zahteva(request, idmajstor):
    """Omogućava korisniku da kreira zahtev za majstora i opciono priloži sliku problema."""

    majstor = (
        Majstor.objects
        .select_related("korisnik", "korisnik__idgra")
        .prefetch_related(
            Prefetch(
                "majstorkategorija_set",
                queryset=MajstorKategorija.objects.select_related("idkat")
            )
        )
        .get(korisnik=idmajstor)
    )

    if request.method == "POST":
        akcija = request.POST.get("akcija")
        if akcija == "reset":
            return render(request, "core/kreiranje_zahteva.html", {
                "majstor": majstor,
            })
        if akcija == "dodaj_zahtev":
            kategorijaid = request.POST.get("kategorijaid")
            naslov = request.POST.get("naslov")
            opis = request.POST.get("opis")
            napomena = request.POST.get("napomena")
            adresa = request.POST.get("adresa")
            slika = request.FILES.get("slikaProblema")

            if slika:
                dozvoljeni_tipovi = {
                    "image/jpeg": ".jpg",
                    "image/png": ".png",
                    "image/webp": ".webp",
                }

                if slika.content_type not in dozvoljeni_tipovi:
                    messages.error(request, "Dozvoljene su JPG, PNG i WEBP fotografije.")
                    return render(request, "core/kreiranje_zahteva.html", {
                        "majstor": majstor,
                    })

                if slika.size > 5 * 1024 * 1024:
                    messages.error(request, "Fotografija može imati najviše 5 MB.")
                    return render(request, "core/kreiranje_zahteva.html", {
                        "majstor": majstor,
                    })

            zahtev = Zahtev.objects.create(
                korisnik = Korisnik.objects.get(idkor = request.session["idKor"]),
                majstor = majstor,
                kategorija =  Kategorija.objects.get(idkat=kategorijaid),
                naslov = naslov,
                opis = opis,
                napomene = napomena,
                adresa = adresa,
                datum=timezone.localdate(),
                status="NA_CEKANJU",
            )
            if slika:
                ekstenzija = Path(slika.name).suffix.lower()
                if ekstenzija not in {".jpg", ".jpeg", ".png", ".webp"}:
                    ekstenzija = dozvoljeni_tipovi[slika.content_type]
                elif ekstenzija == ".jpeg":
                    ekstenzija = ".jpg"

                naziv = f"zahtev_{zahtev.idzah}_{uuid4().hex}{ekstenzija}"
                skladiste = FileSystemStorage(
                    location=settings.MEDIA_ROOT / "problemi",
                    base_url=f"{settings.MEDIA_URL}problemi/",
                )
                sacuvani_naziv = skladiste.save(naziv, slika)
                SlikaProblema.objects.create(
                    idzah=zahtev,
                    putanja=f"problemi/{sacuvani_naziv}",
                )
            zahtevi = Zahtev.objects.filter(korisnik = Korisnik.objects.get(idkor = request.session['idKor']))
            return render(request, "core/zahtevi_korisnika.html", {
                'zahtevi': zahtevi,
            })


    return render(request, "core/kreiranje_zahteva.html", {
        "majstor": majstor,
    })

def zahtevi_korisnika(request):
    """Prikazuje sve zahteve koje je kreirao trenutno prijavljeni korisnik."""

    if "idKor" not in request.session:
        return redirect('index')
    korisnik_id = request.session["idKor"]

    #korisnik = Korisnik.objects.get(idkor=korisnik_id)

    zahtevi = Zahtev.objects.filter(
        korisnik_id=korisnik_id
    ).select_related(
        'majstor__korisnik',
        'kategorija'
    )

    return render(request, 'core/zahtevi_korisnika.html', {
        'zahtevi': zahtevi,
        #'korisnik': korisnik
    })

def _slobodni_termini_za_zahtev(zahtev):
    """Vrati jednosatne termine majstora u narednih 60 dana."""
    danas = timezone.localdate()
    poslednji_dan = danas + timedelta(days=60)

    dostupnosti = Dostupnost.objects.filter(
        majstor=zahtev.majstor,
        status__iexact="slobodan",
        datum_do__gt=danas,
        datum_od__lte=poslednji_dan,
    ).order_by("datum_od")

    zauzeti_termini = Termin.objects.filter(
        idzah__majstor=zahtev.majstor,
        status="ZAKAZAN",
        datum__range=(danas, poslednji_dan),
    ).values("datum", "vremeod", "vremedo")

    zauzeti_po_datumu = {}
    for termin in zauzeti_termini:
        zauzeti_po_datumu.setdefault(termin["datum"], []).append(termin)

    sada = timezone.localtime()
    slobodni_termini = []
    obradjeni_datumi = set()

    for dostupnost in dostupnosti:
        datum = max(dostupnost.datum_od, danas)
        kraj_perioda = min(dostupnost.datum_do, poslednji_dan + timedelta(days=1))

        # datum_do se u bazi čuva kao isključiva gornja granica perioda.
        while datum < kraj_perioda:
            if datum not in obradjeni_datumi:
                obradjeni_datumi.add(datum)

                for sat in range(8, 18):
                    vreme_od = time(sat, 0)
                    vreme_do = time(sat + 1, 0)

                    if datum == danas and vreme_od <= sada.time():
                        continue

                    preklapanje = any(
                        zauzeti["vremeod"] < vreme_do
                        and zauzeti["vremedo"] > vreme_od
                        for zauzeti in zauzeti_po_datumu.get(datum, [])
                    )

                    if not preklapanje:
                        slobodni_termini.append({
                            "datum": datum,
                            "vreme_od": vreme_od,
                            "vreme_do": vreme_do,
                            "vrednost": f"{datum.isoformat()}|{vreme_od.strftime('%H:%M')}",
                        })

            datum += timedelta(days=1)

    return slobodni_termini


def _aktivni_termini_za_zahtev(zahtev):
    """Zakazani termini koji još nisu prošli."""
    danas = timezone.localdate()
    trenutno_vreme = timezone.localtime().time()

    return Termin.objects.filter(
        idzah=zahtev,
        status="ZAKAZAN",
    ).filter(
        Q(datum__gt=danas)
        | Q(datum=danas, vremedo__gt=trenutno_vreme)
    )


def prikaz_stranice_zahteva_korisnika(request, idzah):
    """Prikazuje detalje korisnikovog zahteva i obrađuje prijavu, termin, ocenu i komentar."""

    if "idKor" not in request.session:
        return redirect('index')
    zahtev = get_object_or_404(
        Zahtev.objects.select_related(
            'korisnik',
            'majstor__korisnik',
            'kategorija'
        ),
        idzah=idzah
    )

    korisnik = zahtev.korisnik
    poruke = Poruka.objects.filter(idzah=idzah).order_by('idpor')
    slike = SlikaProblema.objects.filter(idzah=zahtev).order_by('idsli')
    trenutni_korisnik_id = request.session.get('idKor')

    if zahtev.korisnik_id != trenutni_korisnik_id:
        messages.error(request, "Nemate dozvolu da pristupite ovom zahtevu.")
        return redirect("zahtevi_korisnika")

    zakazani_termin = _aktivni_termini_za_zahtev(zahtev).order_by(
        "datum", "vremeod"
    ).first()

    if request.method == "POST":
        akcija = request.POST.get("akcija")


        if akcija == "prijava_problema":
            opis_prijave = request.POST.get("opis_prijave")

            if opis_prijave:
                Prijava.objects.create(
                    korisnik=korisnik,
                    zahtev=zahtev,
                    opis=opis_prijave,
                    status="POSLATA"
                )

        elif akcija == "zakazi_termin":
            izabrani_termin = request.POST.get("termin", "").strip()

            if zahtev.status != "PRIHVACEN":
                messages.error(request, "Termin se može zakazati samo za prihvaćen zahtev.")
            elif zakazani_termin:
                messages.warning(request, "Za ovaj zahtev već postoji zakazan termin.")
            else:
                try:
                    datum_tekst, vreme_tekst = izabrani_termin.split("|", 1)
                    datum_termina = datetime.strptime(datum_tekst, "%Y-%m-%d").date()
                    vreme_od = datetime.strptime(vreme_tekst, "%H:%M").time()
                    if vreme_od.minute != 0 or not 8 <= vreme_od.hour < 18:
                        raise ValueError
                except (TypeError, ValueError):
                    messages.error(request, "Izaberite jedan od ponuđenih termina.")
                else:
                    vreme_do = time(vreme_od.hour + 1, vreme_od.minute)

                    with transaction.atomic():
                        # Zaključavanje majstora sprečava dva istovremena zakazivanja.
                        Majstor.objects.select_for_update().get(pk=zahtev.majstor_id)

                        slobodne_vrednosti = {
                            termin["vrednost"]
                            for termin in _slobodni_termini_za_zahtev(zahtev)
                        }

                        if izabrani_termin not in slobodne_vrednosti:
                            messages.error(
                                request,
                                "Izabrani termin više nije slobodan. Izaberite drugi termin."
                            )
                        elif _aktivni_termini_za_zahtev(zahtev).exists():
                            messages.warning(request, "Za ovaj zahtev već postoji zakazan termin.")
                        else:
                            Termin.objects.create(
                                idzah=zahtev,
                                datum=datum_termina,
                                vremeod=vreme_od,
                                vremedo=vreme_do,
                                status="ZAKAZAN",
                            )
                            Notifikacija.objects.create(
                                idkor=zahtev.majstor.korisnik,
                                idzah=zahtev,
                                tekst=(
                                    f"Zakazan je termin za zahtev '{zahtev.naslov}' "
                                    f"{datum_termina.strftime('%d.%m.%Y.')} "
                                    f"od {vreme_od.strftime('%H:%M')} do {vreme_do.strftime('%H:%M')}."
                                ),
                                procitana=False,
                            )
                            messages.success(request, "Termin je uspešno zakazan.")

        elif akcija == "sacuvaj_ocenu_komentar":
            ocena = request.POST.get("ocena")
            komentar = request.POST.get("komentar")

            if ocena or komentar:
                ocena_obj, created = Ocena.objects.get_or_create(
                    zahtev=zahtev,
                    defaults={
                        "ocena": None,
                        "komentar": None
                    }
                )
                sacuvana_ocena = False
                sacuvan_komentar = False
                vec_ocena = False
                vec_komentar = False

                if ocena:
                    if ocena_obj.ocena is None:
                        ocena_obj.ocena = int(ocena)
                        sacuvana_ocena = True
                    else:
                        vec_ocena = True
                if komentar:
                    if not ocena_obj.komentar:
                        ocena_obj.komentar = komentar
                        sacuvan_komentar = True
                    else:
                        vec_komentar = True

                if sacuvana_ocena or sacuvan_komentar:
                    ocena_obj.save()
                    if sacuvana_ocena:
                        prosek = (
                            Ocena.objects
                            .filter(zahtev__majstor=zahtev.majstor, ocena__isnull=False)
                            .aggregate(Avg('ocena'))
                        )['ocena__avg']
                        zahtev.majstor.prosecnaocena = prosek
                        zahtev.majstor.save()
                if sacuvana_ocena and sacuvan_komentar:
                    messages.success(request, "Ocena i komentar su uspešno sačuvani.")
                elif sacuvana_ocena:
                    messages.success(request, "Ocena je uspešno sačuvana.")
                elif sacuvan_komentar:
                    messages.success(request, "Komentar je uspešno sačuvan.")
                elif vec_ocena and vec_komentar:
                    messages.warning(request, "Već ste ostavili i ocenu i komentar.")
                elif vec_ocena:
                    messages.warning(request, "Već ste ostavili ocenu.")
                elif vec_komentar:
                    messages.warning(request, "Već ste ostavili komentar.")

        return redirect('prikaz_zahteva_korisnika', idzah=zahtev.idzah)

    slobodni_termini = []
    if zahtev.status == "PRIHVACEN" and not zakazani_termin:
        slobodni_termini = _slobodni_termini_za_zahtev(zahtev)

    return render(request, 'core/prikaz_zahteva_korisnika.html', {
        'zahtev': zahtev,
        'korisnik': korisnik,
        'poruke': poruke,
        'slike': slike,
        'trenutni_korisnik_id': trenutni_korisnik_id,
        'zakazani_termin': zakazani_termin,
        'slobodni_termini': slobodni_termini,
    })

def zakazivanje_termina(request):
    """Prikazuje samostalni šablon stranice namenjene zakazivanju termina."""

    return render(request, "core/zakazivanje_termina.html")


#   OBRADA ZAHTEVA i KOMUNIKACIJA MAJSTORA
def zahtevi_za_posao_majstora(request):
    """Prikazuje sve zahteve za posao koji su upućeni trenutno prijavljenom majstoru."""

    if "idKor" not in request.session:
        return redirect('index')
    majstor_id = request.session["idKor"]
    zahtevi = Zahtev.objects.filter(
        majstor_id=majstor_id
    ).select_related(
        'korisnik',
        'kategorija'
    )
    return render(request, "core/zahtevi_za_posao_majstora.html", {
        "zahtevi": zahtevi,
    })

def prikaz_stranice_zahteva_za_posao_majstora(request, idzah):
    """Prikazuje majstoru detalje izabranog zahteva, poruke i priložene slike problema."""

    if "idKor" not in request.session:
        return redirect("index")

    poruke = Poruka.objects.filter(
        idzah=idzah
    ).order_by("idpor")

    trenutni_korisnik_id = request.session.get("idKor")

    zahtev = get_object_or_404(
        Zahtev.objects.select_related(
            "korisnik",
            "majstor__korisnik",
            "kategorija"
        ),
        idzah=idzah
    )

    korisnik = zahtev.korisnik

    if request.method == "POST":
        akcija = request.POST.get("akcija")

        if akcija == "prijava_problema":
            opis_prijave = request.POST.get("opis_prijave", "").strip()

            if opis_prijave:
                Prijava.objects.create(
                    korisnik=korisnik,
                    zahtev=zahtev,
                    opis=opis_prijave,
                    status="POSLATA"
                )

                administratori = Korisnik.objects.filter(
                    idulo_id=3
                )

                for administrator in administratori:
                    Notifikacija.objects.create(
                        idkor=administrator,
                        tekst=opis_prijave,
                        procitana=0,
                        idzah=zahtev
                    )

        return redirect(
            "prikaz_zahteva_korisnika",
            idzah=zahtev.idzah
        )

    return render(
        request,
        "core/prikaz_zahteva_za_posao_majstora.html",
        {
            "zahtev": zahtev,
            "poruke": poruke,
            "trenutni_korisnik_id": trenutni_korisnik_id
        }
    )


def zahtev_view(request, idzah):
    """Prikazuje majstoru stranicu za obradu konkretnog zahteva korisnika."""

    if "idKor" not in request.session:
        return redirect("index")

    zahtev = Zahtev.objects.get(idzah=idzah)
    slike = SlikaProblema.objects.filter(idzah=zahtev).order_by('idsli')

    broj_neprocitanih = Notifikacija.objects.filter(
        idkor_id=request.session["idKor"],
        procitana=0
    ).count()

    return render(request, "core/obrada_zahteva.html", {
        "zahtev": zahtev,
        "slike": slike,
        "broj_neprocitanih": broj_neprocitanih
    })

def prihvati_zahtev_view(request, idzah):
    """Menja status izabranog zahteva u prihvaćen i vraća majstora na njegovu obradu."""

    if "idKor" not in request.session:
        return redirect("login")

    Zahtev.objects.filter(idzah=idzah).update(status="PRIHVACEN")
    return redirect("prikaz_zahteva_za_posao_majstora", idzah=idzah)

def odbij_zahtev_view(request, idzah):
    """Menja status izabranog zahteva u odbijen i vraća majstora na njegovu obradu."""

    if "idKor" not in request.session:
        return redirect("login")

    Zahtev.objects.filter(idzah=idzah).update(status="ODBIJEN")

    return redirect("zahtevi_za_posao_majstora")

def chat_view(request, idzah):
    """Prikazuje razgovor korisnika i majstora povezan sa određenim zahtevom."""

    if "idKor" not in request.session:
        return redirect("login")

    id_ulogovanog = request.session["idKor"]

    zahtev = Zahtev.objects.get(idzah=idzah)

    id_korisnika_iz_zahteva = zahtev.korisnik.idkor

    if request.method == "POST":
        tekst = request.POST.get("tekst")

        if tekst:
            posiljalac = Korisnik.objects.get(idkor=id_ulogovanog)
            primalac = Korisnik.objects.get(idkor=id_korisnika_iz_zahteva)

            Poruka.objects.create(
                idzah=zahtev,
                idposiljalac=posiljalac,
                idprimalac=primalac,
                tekst=tekst,
                vreme=timezone.now().time(),
                procitano=0
            )

            return redirect("chat", idzah=idzah)

    poruke = Poruka.objects.filter(
        idzah=zahtev
    ).filter(
        Q(idposiljalac_id=id_ulogovanog, idprimalac_id=id_korisnika_iz_zahteva) |
        Q(idposiljalac_id=id_korisnika_iz_zahteva, idprimalac_id=id_ulogovanog)
    ).order_by("idpor")

    broj_neprocitanih = Notifikacija.objects.filter(
        idkor_id=id_ulogovanog,
        procitana=0
    ).count()

    return render(request, "core/chat.html", {
        "zahtev": zahtev,
        "poruke": poruke,
        "id_ulogovanog": id_ulogovanog,
        "broj_neprocitanih": broj_neprocitanih
    })


#   ADMIN FUNKCIONALNOSTI
def lista_korisnika(request):
    """Prikazuje administratoru listu svih korisnika i označava naloge koji pripadaju majstorima."""

    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 3:
        return redirect("index")

    korisnici = Korisnik.objects.select_related("idulo").all()

    majstori_ids = list(
        Majstor.objects.values_list("korisnik_id", flat=True)
    )

    return render(request, "core/lista_korisnika.html", {
        "korisnici": korisnici,
        "majstori_ids": majstori_ids,
    })

def lista_zahteva_majstora(request):
    """Prikazuje administratoru zahteve za verifikaciju majstora i obrađuje prihvatanje ili odbijanje."""

    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 3:
        return redirect("/")
    if request.method == "POST":
        akcija = request.POST.get("akcija")
        idmajstor = request.POST.get("idmajstor")

        majstor = get_object_or_404(Majstor, korisnik_id=idmajstor)

        if akcija == "prihvati":
            majstor.verifikacija = "VERIFIKOVAN"
            majstor.razlogodbijanja = None

        elif akcija == "odbij":
            majstor.verifikacija = "ODBIJEN"
            majstor.razlogodbijanja = request.POST.get("razlogOdbijanja")

        majstor.save()

        return redirect("lista_zahteva_majstora")

    zahtevi = Majstor.objects.select_related("korisnik").filter(
        verifikacija="NA_CEKANJU"
    )

    return render(request, "core/lista_zahteva_majstora.html", {
        "zahtevi": zahtevi
    })

def administracija_korisnika(request, idkor):
    """Omogućava administratoru pregled, blokiranje, aktiviranje i izmenu statusa korisnika."""

    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 3:
        return redirect("index")

    korisnik = get_object_or_404(Korisnik, idkor=idkor)

    if request.method == "POST":
        akcija = request.POST.get("akcija")

        if akcija == "blokiraj":
            razlog = request.POST.get("razlog")

            korisnik.status = "BLOKIRAN"
            korisnik.razlogblokiranja = razlog
            korisnik.save()

        elif akcija == "aktiviraj":
            korisnik.status = "AKTIVAN"
            korisnik.razlogblokiranja = None
            korisnik.save()

        elif akcija == "sacuvaj":
            korisnik.status = request.POST.get("status")
            korisnik.save()

        return redirect("administracija_korisnika", idkor=korisnik.idkor)

    return render(request, "core/administracija_korisnika.html", {
        "korisnik": korisnik
    })

def administracija_majstora(request, idmajstor):
    """Omogućava administratoru upravljanje statusom, profilom i kategorijama izabranog majstora."""

    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 3:
        return redirect("index")
    majstor = get_object_or_404(
        Majstor.objects.select_related("korisnik", "korisnik__idgra", "korisnik__idulo"),
        korisnik_id=idmajstor
    )

    korisnik = majstor.korisnik

    if request.method == "POST":
        akcija = request.POST.get("akcija")

        if akcija == "blokiraj":
            razlog = request.POST.get("razlog")

            korisnik.status = "BLOKIRAN"
            korisnik.razlogblokiranja = razlog
            korisnik.save()

        elif akcija == "aktiviraj":
            korisnik.status = "AKTIVAN"
            korisnik.razlogblokiranja = None
            korisnik.save()

        elif akcija == "sacuvaj":
            majstor.opis = request.POST.get("opis")
            majstor.save()

            korisnik.status = request.POST.get("status")
            korisnik.save()

            kategorije = request.POST.getlist("kategorije")

            MajstorKategorija.objects.filter(
                idmajstor=majstor
            ).delete()

            for idkat in kategorije:

                MajstorKategorija.objects.create(
                    idmajstor=majstor,
                    idkat_id=idkat
                )

        return redirect(
            "administracija_majstora",
            idmajstor=korisnik.idkor
        )

    context = {
        "majstor": majstor,
        "sve_kategorije": Kategorija.objects.all(),
        "kategorije_majstora": majstor.kategorije.all()
    }

    return render(
        request,
        "core/administracija_majstora.html",
        context
    )


#   API MAPE i CHATBOT
def lokacije_majstora(request):
    """Vraća JSON podatke o lokacijama verifikovanih majstora za prikaz na mapi."""

    majstori = (
        Majstor.objects
        .select_related("korisnik", "korisnik__idgra")
        .filter(verifikacija="VERIFIKOVAN")
        .exclude(korisnik__latitude__isnull=True)
        .exclude(korisnik__longitude__isnull=True)
    )

    data = [
        {
            "ime": m.korisnik.ime,
            "prezime": m.korisnik.prezime,
            "grad": m.korisnik.idgra.naziv,
            "adresa": m.korisnik.adresa,
            "ocena": m.prosecnaocena,
            "lat": float(m.korisnik.latitude),
            "lng": float(m.korisnik.longitude),
            "url": reverse("profilMajstora", args=[m.korisnik.idkor]),
        }
        for m in majstori
    ]

    return JsonResponse(data, safe=False)

client = OpenAI(
    api_key=settings.OPENROUTER_API_KEY,
    base_url="https://openrouter.ai/api/v1"
)

def chatbot(request):

    if request.method == "POST":

        pitanje = request.POST.get("message", "").strip()

        if not pitanje:
            return JsonResponse({
                "answer": "Molim vas unesite pitanje."
            }, status=400)


        majstori = (
            Majstor.objects
            .filter(
                verifikacija="VERIFIKOVAN",
                korisnik__status="AKTIVAN"
            )
            .prefetch_related("kategorije")
            .select_related("korisnik")
            .order_by("-prosecnaocena")
        )


        lista_majstora = []

        for m in majstori:

            kategorije = [
                k.naziv 
                for k in m.kategorije.all()
            ]

            lista_majstora.append({
                "ime": f"{m.korisnik.ime} {m.korisnik.prezime}",
                "telefon": m.korisnik.telefon,
                "ocena": m.prosecnaocena,
                "opis": m.opis,
                "kategorije": kategorije
            })


        import json

        podaci = json.dumps(
            lista_majstora,
            ensure_ascii=False,
            indent=2
        )


        odgovor = client.chat.completions.create(

            model="google/gemini-2.5-flash",

            temperature=0.2,

            max_tokens=500,

            messages=[

                {
                    "role": "system",
                    "content": """
Ti si AI asistent aplikacije MojMajstor.

Pomažeš korisnicima iz Srbije da pronađu odgovarajućeg majstora.

PRAVILA:

- Odgovaraj isključivo na srpskom jeziku latinicom.
- Koristi prirodan govor koji koristi običan čovek u Srbiji.
- Razumi različite načine izražavanja problema.

Primeri:
"crkla mi je slavina"
"curi mi voda"
"imam problem sa cevima"

znače da korisnik verovatno traži vodoinstalatera.

"nestala mi je struja"
"ne radi utičnica"

znače da korisnik verovatno traži električara.

- Koristi ISKLJUČIVO podatke o majstorima koje dobiješ.
- Ne izmišljaj majstore.
- Ne menjaj ocene, telefone ili kategorije.
- Ako nema odgovarajućeg majstora napiši da nije pronađen.
- Nemoj navoditi majstore koji nisu povezani sa problemom korisnika.
- Ako postoji više odgovarajućih majstora, poređaj ih po relevantnosti i oceni.

Format:

Ime i prezime:
Telefon:
Kategorije:
Ocena:
Zašto odgovara:

Odgovor neka bude kratak i prijateljski.
"""
                },

                {
                    "role": "user",
                    "content": f"""
Korisnikovo pitanje:

{pitanje}


Dostupni majstori:

{podaci}


Pronađi najbolje majstore za korisnikov problem.
"""
                }

            ]
        )


        tekst = odgovor.choices[0].message.content


        return JsonResponse({
            "answer": tekst
        })


    return render(request, "core/chatbot.html")


def upravljanje_profilom(request):
    """Omogućava prijavljenom majstoru izmenu profila i ponovnu proveru promenjene adrese."""


    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 2:
        return redirect("index")

    korisnik = get_object_or_404(
        Korisnik.objects.select_related("idgra"),
        idkor=request.session["idKor"]
    )

    majstor = get_object_or_404(
        Majstor,
        korisnik=korisnik
    )

    if request.method == "POST":

        errors = []

        ime = request.POST.get("ime", "").strip()
        prezime = request.POST.get("prezime", "").strip()
        email = request.POST.get("email", "").strip()
        telefon = request.POST.get("telefon", "").strip()
        lokacija = request.POST.get("lokacija", "").strip()
        adresa = request.POST.get("adresa", "").strip()
        opis = request.POST.get("opisUsluga", "").strip()

        if not ime:
            errors.append("Ime ne sme biti prazno.")

        if not prezime:
            errors.append("Prezime ne sme biti prazno.")

        if not email:
            errors.append("Email ne sme biti prazan.")

        if not telefon:
            errors.append("Telefon ne sme biti prazan.")

        if not lokacija:
            errors.append("Lokacija ne sme biti prazna.")

        if not adresa:
            errors.append("Adresa ne sme biti prazna.")

        if not opis or len(opis) < 10:
            errors.append("Opis mora imati minimum 10 karaktera.")

        novi_grad = None

        if lokacija:
            novi_grad = Grad.objects.filter(
                naziv__iexact=lokacija
            ).first()

            if novi_grad is None:
                errors.append("Izabrani grad ne postoji.")

        if errors:
            for error in errors:
                messages.error(request, error)

            return redirect("upravljanje_profilom")

        promenjena_adresa = adresa != korisnik.adresa
        promenjen_grad = novi_grad.idgra != korisnik.idgra_id

        if promenjena_adresa or promenjen_grad:
            try:
                koordinate = geocode_address(
                    adresa,
                    novi_grad.naziv
                )
            except GeocodingServiceError:
                messages.error(
                    request,
                    "Trenutno nije moguće proveriti adresu. "
                    "Pokušajte ponovo."
                )
                return redirect("upravljanje_profilom")

            if koordinate is None:
                messages.error(
                    request,
                    "Adresa nije pronađena u izabranom gradu. "
                    "Proverite ulicu i broj."
                )
                return redirect("upravljanje_profilom")

            korisnik.latitude, korisnik.longitude = koordinate

        korisnik.ime = ime
        korisnik.prezime = prezime
        korisnik.email = email
        korisnik.telefon = telefon
        korisnik.adresa = adresa
        korisnik.idgra = novi_grad
        korisnik.save()

        majstor.opis = opis
        majstor.save()

        request.session["ime"] = korisnik.ime
        request.session["prezime"] = korisnik.prezime

        messages.success(
            request,
            "Promene su uspešno sačuvane!"
        )

        return redirect("upravljanje_profilom")

    context = {
        "korisnik": korisnik,
        "majstor": majstor,
        "kategorije": majstor.kategorije.all(),
        "grad": korisnik.idgra,
    }

    return render(
        request,
        "core/upravljanje_profilom.html",
        context
    )

def upravljanje_dostupnosti(request):
    """Omogućava majstoru pregled i unos perioda u kojima je slobodan ili zauzet."""


    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 2:
        return redirect("index")

    korisnik = ulogovani_korisnik
    majstor = Majstor.objects.get(korisnik=korisnik)

    if request.method == "POST":

        datum_od = request.POST.get("datum_od")
        datum_do = request.POST.get("datum_do")
        status = request.POST.get("status")

        from datetime import datetime

        try:
            datum_od = datetime.strptime(datum_od, "%Y-%m-%d").date()
            datum_do = datetime.strptime(datum_do, "%Y-%m-%d").date()
        except:
            return redirect("upravljanje_dostupnosti")

        if datum_od > datum_do:
            messages.error(request, "Promene nisu sačuvane! Datum OD ne može biti posle datum DO")
            return redirect("upravljanje_dostupnosti")

        datum_do = datum_do + timedelta(days=1)

        postoji_preklapanje = Dostupnost.objects.filter(
            majstor=majstor,
            datum_od__lt=datum_do,
            datum_do__gt=datum_od
        ).exists()

        if postoji_preklapanje:
            messages.error(request, "Promene nisu sačuvane! Postoji preklapanje!")
            return redirect("upravljanje_dostupnosti")

        Dostupnost.objects.create(
            majstor=majstor,
            datum_od=datum_od,
            datum_do=datum_do,
            status=status
        )


        messages.success(request, "Promene su uspešno sačuvane!")
        return redirect("upravljanje_dostupnosti")


    dostupnosti = Dostupnost.objects.filter(
        majstor=majstor
    )

    return render(request, "core/upravljanje_dostupnosti.html", {
        "dostupnosti": dostupnosti
    })

#Namesteno i radi
def prijavljeni_problemi(request):
    """Prikazuje administratoru poslate prijave problema i omogućava njihovo rešavanje."""


    if "idKor" not in request.session:
        return redirect("login")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 3:
        return redirect("index")

    if request.method == "POST":
        idpr = request.POST.get("idpr")
        odgovor = request.POST.get("odgovor", "").strip()

        problem = get_object_or_404(Prijava, idpr=idpr)

        problem.status = "RESENA"
        problem.save()

        odgovor = request.POST.get("odgovor", "").strip()

        if odgovor:
            tekst = f"Problem rešen.\n\nObrazloženje: {odgovor}"
        else:
            tekst = "Problem rešen."

        Notifikacija.objects.create(
            idkor=problem.korisnik,
            tekst=tekst,
            procitana=False
        )

        messages.success(request, "Problem je uspešno rešen.")
        return redirect("prijavljeni_problemi")

    problemi = Prijava.objects.all().filter(status='POSLATA').order_by('-idpr')

    return render(request, 'core/prijavljeni_problemi.html', {
        'problemi': problemi
    })

def administracija_majstoraBojan(request, idmajstor):
    """Predstavlja pomoćnu administratorsku funkciju za izmenu kategorija izabranog majstora."""

    if "idKor" not in request.session:
        return redirect("index")

    ulogovani_korisnik = get_object_or_404(
        Korisnik,
        idkor=request.session["idKor"]
    )

    if ulogovani_korisnik.idulo_id != 3:
        return redirect("index")
    majstor = get_object_or_404(
        Majstor.objects.select_related("korisnik", "korisnik__idgra", "korisnik__idulo"),
        korisnik_id=idmajstor
    )

    korisnik = majstor.korisnik

    if request.method == "POST":

        akcija = request.POST.get("akcija")

        if akcija == "sacuvaj":
            kategorije = request.POST.getlist("kategorije")

            MajstorKategorija.objects.filter(
                majstor=majstor
            ).delete()

            for idkat in kategorije:

                MajstorKategorija.objects.create(
                    majstor=majstor,
                    kategorija_id=idkat
                )

            return redirect(
                f"/administracija_majstora/?idMajstor={majstor.korisnik.idkor}"
            )

        return redirect(
            f"/administracija_majstora/?idMajstor={majstor.korisnik.idkor}"
        )


    sve_kategorije = Kategorija.objects.all()

    kategorije_majstora = []

    if majstor:
        kategorije_majstora = majstor.kategorije.all()


    context = {
        "majstor": majstor,
        "sve_kategorije": sve_kategorije,
        "kategorije_majstora": kategorije_majstora
    }

    return render(
        request,
        "core/administracija_majstora.html",
        context
    )


def profil_korisnik(request, idKor):
    """Prikazuje i ažurira profil prijavljenog korisnika uz validaciju jedinstvenih i adresnih podataka."""

    if "idKor" not in request.session:
        return redirect("index")

    if request.session["idKor"] != idKor:
        return redirect("profil", idKor=request.session["idKor"])

    korisnik = get_object_or_404(
        Korisnik.objects.select_related("idgra"),
        idkor=idKor
    )
    gradovi = Grad.objects.all().order_by("naziv")

    if "idKor" not in request.session:
        return redirect("login")

    if request.method == "POST":
        ime = request.POST.get("ime", "").strip()
        prezime = request.POST.get("prezime", "").strip()
        username = request.POST.get("username", "").strip()
        email = request.POST.get("email", "").strip()
        telefon = request.POST.get("telefon", "").strip()
        adresa = request.POST.get("adresa", "").strip()
        idgra = request.POST.get("idgra")

        if not all([ime, prezime, username, email, telefon, adresa, idgra]):
            messages.error(request, "Sva polja su obavezna.")
            return redirect("profil", idKor=korisnik.idkor)

        if Korisnik.objects.filter(username=username).exclude(idkor=korisnik.idkor).exists():
            messages.error(request, "Korisničko ime je već zauzeto.")
            return redirect("profil", idKor=korisnik.idkor)

        if Korisnik.objects.filter(email=email).exclude(idkor=korisnik.idkor).exists():
            messages.error(request, "Email adresa je već zauzeta.")
            return redirect("profil", idKor=korisnik.idkor)

        grad = get_object_or_404(Grad, idgra=idgra)

        if (
            adresa != korisnik.adresa
            or grad.idgra != korisnik.idgra_id
            or korisnik.latitude is None
            or korisnik.longitude is None
        ):
            try:
                koordinate = geocode_address(adresa, grad.naziv)
            except GeocodingServiceError:
                messages.error(
                    request,
                    "Trenutno nije moguće proveriti adresu. Pokušajte ponovo."
                )
                return redirect("profil", idKor=korisnik.idkor)

            if koordinate is None:
                messages.error(
                    request,
                    "Adresa nije pronađena u izabranom gradu. Proverite ulicu i broj."
                )
                return redirect("profil", idKor=korisnik.idkor)

            korisnik.latitude, korisnik.longitude = koordinate

        korisnik.ime = ime
        korisnik.prezime = prezime
        korisnik.username = username
        korisnik.email = email
        korisnik.telefon = telefon
        korisnik.adresa = adresa
        korisnik.idgra = grad
        korisnik.save()

        request.session["ime"] = korisnik.ime
        request.session["prezime"] = korisnik.prezime
        request.session["username"] = korisnik.username

        messages.success(request, "Profil je uspešno sačuvan.")
        return redirect("profil", idKor=korisnik.idkor)


    return render(request, "core/profil.html", {
        "korisnik": korisnik,
        "gradovi": gradovi,
    })
