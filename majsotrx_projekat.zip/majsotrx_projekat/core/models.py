from django.conf import settings
from django.db import models

# Create your models here.

class Uloga(models.Model):
    """Predstavlja ulogu korisnika u sistemu, kao što su korisnik, majstor ili administrator."""

    iduloga = models.AutoField(db_column='idUloga', primary_key=True)  # Field name made lowercase.
    naziv = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'uloga'


class Grad(models.Model):
    """Čuva naziv grada i njegove geografske koordinate."""

    idgra = models.AutoField(db_column='idGra', primary_key=True)
    naziv = models.CharField(max_length=45)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'grad'

class Kategorija(models.Model):
    """Predstavlja kategoriju usluge koju majstor može da pruža."""

    idkat = models.AutoField(db_column='idKat', primary_key=True)  # Field name made lowercase.
    naziv = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'kategorija'

class Korisnik(models.Model):
    """Čuva lične, kontaktne, pristupne i lokacijske podatke korisnika aplikacije."""

    idkor = models.AutoField(db_column='idKor', primary_key=True)  # Field name made lowercase.
    ime = models.CharField(max_length=45)
    prezime = models.CharField(max_length=45)
    email = models.CharField(unique=True, max_length=45)
    username = models.CharField(unique=True, max_length=45)
    lozinka = models.CharField(max_length=45)
    telefon = models.CharField(max_length=45)
    adresa = models.CharField(max_length=45)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, blank=True, null=True)
    idgra = models.ForeignKey(Grad, models.DO_NOTHING, db_column='idGra')  # Field name made lowercase.
    idulo = models.ForeignKey('Uloga', models.DO_NOTHING, db_column='idUlo')  # Field name made lowercase.
    status = models.CharField(max_length=11)
    razlogblokiranja = models.TextField(
        db_column='razlogBlokiranja',
        blank=True,
        null=True
    )

    class Meta:
        managed = False
        db_table = 'korisnik'

class Majstor(models.Model):
    """Proširuje korisnika podacima potrebnim za profil, verifikaciju i usluge majstora."""

    korisnik = models.OneToOneField(
        Korisnik,
        models.DO_NOTHING,
        db_column='idMajstor',
        primary_key=True
    )
    prosecnaocena = models.FloatField(db_column='prosecnaOcena')
    opis = models.TextField(blank=True, null=True)
    verifikacija = models.CharField(
        db_column='verifikacija',
        max_length=20,
        choices=[
            ('NA_CEKANJU', 'Na čekanju'),
            ('VERIFIKOVAN', 'Verifikovan'),
            ('ODBIJEN', 'Odbijen'),
        ],
        default='NA_CEKANJU'
    )

    opisverifikacije = models.TextField(
        db_column='opisVerifikacije',
        blank=True,
        null=True
    )

    razlogodbijanja = models.TextField(
        db_column='razlogOdbijanja',
        blank=True,
        null=True
    )

    kategorije = models.ManyToManyField(
        Kategorija,
        through="MajstorKategorija"
    )

    class Meta:
        managed = False
        db_table = 'majstor'

class Zahtev(models.Model):
    """Predstavlja zahtev korisnika za izvršenje određene usluge kod izabranog majstora."""

    idzah = models.AutoField(db_column='idZah', primary_key=True)
    korisnik = models.ForeignKey(Korisnik, models.DO_NOTHING, db_column='idKor')
    majstor = models.ForeignKey(Majstor, models.DO_NOTHING, db_column='idMajstor')
    kategorija = models.ForeignKey(Kategorija, models.DO_NOTHING, db_column='idKat')
    naslov = models.CharField(max_length=45)
    opis = models.TextField()
    napomene = models.TextField()
    adresa = models.CharField(max_length=100)
    datum = models.DateField()
    status = models.CharField(max_length=10)

    class Meta:
        managed = False
        db_table = 'zahtev'


class Prijava(models.Model):
    """Čuva prijavu problema koju je korisnik podneo u vezi sa određenim zahtevom."""

    STATUS_CHOICES = [
        ('POSLATA', 'Poslata'),
        ('RESENA', 'Rešena'),
        ('ODBIJENA', 'Odbijena'),
    ]

    idpr = models.AutoField(db_column='idPri', primary_key=True)
    korisnik = models.ForeignKey(Korisnik, models.DO_NOTHING, db_column='idKor')
    zahtev = models.ForeignKey(Zahtev, models.DO_NOTHING, db_column='idZah')
    opis = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='POSLATA')

    class Meta:
        managed = False
        db_table = 'prijava_problema'

class Dostupnost(models.Model):
    """Evidentira periode tokom kojih je majstor slobodan ili zauzet."""

    iddost = models.AutoField(db_column="idDost", primary_key=True)

    majstor = models.ForeignKey(
        Majstor,
        models.DO_NOTHING,
        db_column="idMajstor",
        related_name="dostupnosti"
    )

    datum_od = models.DateField(db_column="datumOd")
    datum_do = models.DateField(db_column="datumDo")

    STATUS_CHOICES = [
        ("zauzet", "Zauzet"),
        ("slobodan", "Slobodan")
    ]

    status = models.CharField(max_length=10, choices=STATUS_CHOICES)

    class Meta:
        managed = False
        db_table = "dostupnost"

class Ocena(models.Model):
    """Čuva ocenu i komentar koje je korisnik ostavio nakon izvršenog zahteva."""

    idoce = models.AutoField(db_column='idOce', primary_key=True)

    zahtev = models.ForeignKey(
        Zahtev,
        models.DO_NOTHING,
        db_column='idZah'
    )
    ocena = models.IntegerField(db_column='ocena', blank=True, null=True)
    komentar = models.TextField(db_column='komentar', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ocena'

class Notifikacija(models.Model):
    """Predstavlja obaveštenje namenjeno korisniku, opciono povezano sa određenim zahtevom."""

    idnot = models.AutoField(db_column='idNot', primary_key=True)
    idkor = models.ForeignKey(Korisnik, models.DO_NOTHING, db_column='idKor')
    tekst = models.TextField()
    procitana = models.IntegerField(blank=True, null=True)
    idzah = models.ForeignKey('Zahtev',models.DO_NOTHING,db_column='idZahtev',blank=True,null=True)

    class Meta:
        managed = False
        db_table = 'notifikacija'

class Poruka(models.Model):
    """Čuva poruku razmenjenu između korisnika i majstora u okviru zahteva."""

    idpor = models.AutoField(db_column='idPor', primary_key=True)  # Field name made lowercase.
    idzah = models.ForeignKey('Zahtev', models.DO_NOTHING, db_column='idZah')  # Field name made lowercase.
    idposiljalac = models.ForeignKey(Korisnik, models.DO_NOTHING, db_column='idPosiljalac')  # Field name made lowercase.
    tekst = models.TextField()
    vreme = models.DateTimeField()
    idprimalac = models.ForeignKey(Korisnik, models.DO_NOTHING, db_column='idPrimalac', related_name='poruka_idprimalac_set')  # Field name made lowercase.
    procitano = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'poruka'

class MajstorKategorija(models.Model):
    """Povezuje majstora sa jednom od kategorija usluga koje pruža."""

    pk = models.CompositePrimaryKey('idmajstor', 'idkat')
    idmajstor = models.ForeignKey(Majstor, models.DO_NOTHING, db_column='idMajstor')  # Field name made lowercase.
    idkat = models.ForeignKey(Kategorija, models.DO_NOTHING, db_column='idKat')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'majstor_kategorija'


class Opstina(models.Model):
    """Predstavlja opštinu koja pripada određenom gradu."""

    idopstina = models.AutoField(db_column='idOpstina', primary_key=True)  # Field name made lowercase.
    naziv = models.CharField(max_length=45, blank=True, null=True)
    idgra = models.ForeignKey(Grad, models.DO_NOTHING, db_column='idGra')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'opstina'


class SlikaProblema(models.Model):
    """Čuva putanju do slike problema priložene uz zahtev korisnika."""

    idsli = models.AutoField(db_column='idSli', primary_key=True)  # Field name made lowercase.
    idzah = models.ForeignKey('Zahtev', models.DO_NOTHING, db_column='idZah')  # Field name made lowercase.
    putanja = models.CharField(max_length=255)

    @property
    def url(self):
        putanja = (self.putanja or '').replace('\\', '/').lstrip('/')

        # Podrška za stare zapise oblika /uploads/problemi/slika.jpg.
        if putanja.startswith('uploads/'):
            putanja = putanja[len('uploads/'):]
        elif putanja.startswith('media/'):
            putanja = putanja[len('media/'):]

        return f"{settings.MEDIA_URL.rstrip('/')}/{putanja}"

    class Meta:
        managed = False
        db_table = 'slika_problema'


class Termin(models.Model):
    """Predstavlja datum, vremenski interval i status termina zakazanog za zahtev."""

    idter = models.AutoField(db_column='idTer', primary_key=True)  # Field name made lowercase.
    idzah = models.ForeignKey('Zahtev', models.DO_NOTHING, db_column='idZah')  # Field name made lowercase.
    datum = models.DateField()
    vremeod = models.TimeField(db_column='vremeOd')  # Field name made lowercase.
    vremedo = models.TimeField(db_column='vremeDo')  # Field name made lowercase.
    status = models.CharField(max_length=7)

    class Meta:
        managed = False
        db_table = 'termin'
