import json
from datetime import datetime
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async

from core.models import Korisnik


class ChatConsumer(AsyncWebsocketConsumer):
    #def __init__(self, *args: Unused, **kwargs: Unused):
    #    super().__init__(args, kwargs)
    #    self.room_group_name = None
    #    self.idkor = None
    #    self.idzah = None

    async def connect(self):
        self.idzah = self.scope['url_route']['kwargs']['idzah']
        self.idkor = self.scope['url_route']['kwargs']['idkor']

        #ima_pristup = await self.proveri_pristup()
        #if not ima_pristup:
        #    await self.close()
        #    return

        self.room_group_name = f'chat_{self.idzah}'
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data):
        data = json.loads(text_data)
        tekst = data.get('tekst', '').strip()
        if not tekst:
            return

        poruka = await self.save_message(tekst)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'idpor': poruka.idpor,
                'tekst': poruka.tekst,
                'idposiljalac': poruka.idposiljalac.idkor,
                'vreme': poruka.vreme.strftime('%H:%M'),
            }
        )

    async def chat_message(self, event):
        await self.send(text_data=json.dumps(event))

    @database_sync_to_async
    def save_message(self, tekst):
        from .models import Poruka, Zahtev

        zahtev = Zahtev.objects.get(idzah=self.idzah)
        korisnik = Korisnik.objects.get(idkor=self.idkor)

        if self.idkor == zahtev.korisnik.idkor:
            idprimalac = zahtev.majstor.korisnik
        else:
            idprimalac = zahtev.korisnik

        return Poruka.objects.create(
            idzah=zahtev,
            idposiljalac=korisnik,
            idprimalac=idprimalac,
            tekst=tekst,
            vreme=datetime.now(),
            procitano=0,
        )