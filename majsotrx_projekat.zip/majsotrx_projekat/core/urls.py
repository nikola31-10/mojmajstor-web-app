from django.urls import path
from . import views

urlpatterns = [

    #   INDEX, NOTIFIKACIJE, LOGIN i REGISTRACIJA
    # Prikazuje početnu stranicu sa ponudom verifikovanih majstora.
    path('', views.index, name='index'),
    # Prikazuje obaveštenja trenutno prijavljenog korisnika.
    path("notifikacije/", views.notifikacije_view, name="notifikacije"),
    # Prikazuje i obrađuje formu za prijavu korisnika.
    path("login/", views.login_view, name="login"),
    # Odjavljuje korisnika i uklanja njegove podatke iz sesije.
    path('logout/', views.logout_view, name="logout"),
    # Prikazuje i obrađuje registraciju novog korisnika ili majstora.
    path("registracija/", views.registracija_view, name="registracija"),


    #   PROCES ZAHTEVA KORISNIKA
    # Prikazuje javni profil majstora određenog identifikatorom korisnika.
    path('profilMajstora/<int:idKor>/', views.profil_majstora, name='profilMajstora'),
    # Omogućava kreiranje novog zahteva za izabranog majstora.
    path('kreiranje_zahteva/<int:idmajstor>/', views.kreiranje_zahteva, name='kreiranje_zahteva'),
    # Prikazuje sve zahteve trenutno prijavljenog korisnika.
    path('zahtevi_korisnika/', views.zahtevi_korisnika, name='zahtevi_korisnika'),
    # Prikazuje detalje konkretnog korisničkog zahteva i njegove akcije.
    path('prikaz_zahteva_korisnika/<int:idzah>/', views.prikaz_stranice_zahteva_korisnika, name='prikaz_zahteva_korisnika'),
    # Prikazuje samostalnu stranicu namenjenu zakazivanju termina.
    path('zakazivanje_termina/', views.zakazivanje_termina, name='zakazivanje_termina'),
    # Prikazuje i obrađuje profil korisnika sa prosleđenim identifikatorom.
    path('profil/<int:idKor>/', views.profil_korisnik, name="profil"),


    #path('administracija_korisnika/', views.administracija_korisnika, name='administracija_korisnika'),
    #path('administracija_majstora/', views.administracija_majstora, name='administracija_majstora'),


    #   OBRADA ZAHTEVA i KOMUNIKACIJA MAJSTORA
    # Prikazuje majstoru sve zahteve za posao koji su mu upućeni.
    path("zahtevi_za_posao_majstora/", views.zahtevi_za_posao_majstora, name="zahtevi_za_posao_majstora"),
    # Prikazuje majstoru detalje konkretnog zahteva za posao.
    path("prikaz_zahteva_za_posao_majstora/<int:idzah>", views.prikaz_stranice_zahteva_za_posao_majstora, name="prikaz_zahteva_za_posao_majstora"),
    # Prikazuje stranicu za obradu izabranog zahteva.
    path("obrada_zahteva/<int:idzah>/", views.zahtev_view, name="obrada_zahteva"),
    # Menja status izabranog zahteva u prihvaćen.
    path("obrada_zahteva/<int:idzah>/prihvati/", views.prihvati_zahtev_view, name="prihvati_zahtev"),
    # Menja status izabranog zahteva u odbijen.
    path("obrada_zahteva/<int:idzah>/odbij/", views.odbij_zahtev_view, name="odbij_zahtev"),
    # Prikazuje razgovor korisnika i majstora za određeni zahtev.
    path("chat/<int:idzah>/", views.chat_view, name="chat"),


    #   ADMIN FUNKCIONALNOSTI
    # Prikazuje administratoru listu svih korisnika aplikacije.
    path('lista_korisnika/', views.lista_korisnika, name='lista_korisnika'),
    # Prikazuje administratoru zahteve za verifikaciju majstora.
    path('lista_zahteva_majstora/', views.lista_zahteva_majstora, name='lista_zahteva_majstora'),
    # Omogućava administratoru upravljanje izabranim korisnikom.
    path('administracija_korisnika/<int:idkor>/', views.administracija_korisnika, name='administracija_korisnika'),
    # Omogućava administratoru upravljanje izabranim majstorom.
    path('administracija_majstora/<int:idmajstor>/', views.administracija_majstora, name='administracija_majstora'),
    # Prikazuje administratoru prijavljene probleme i njihovu obradu.
    path('prijavljeni_problemi/', views.prijavljeni_problemi, name='prijavljeni_problemi'),

    #   MAJSTOR FUNKCIONALNOSTI
    # Omogućava majstoru pregled i unos perioda dostupnosti.
    path('upravljanje_dostupnosti/', views.upravljanje_dostupnosti, name='upravljanje_dostupnosti'),
    # Omogućava majstoru pregled i izmenu podataka profila.
    path('upravljanje_profilom/', views.upravljanje_profilom, name='upravljanje_profilom'),


    #   API MAPE i CHATBOT
    # Vraća JSON podatke o lokacijama verifikovanih majstora.
    path("api/lokacije-majstora/", views.lokacije_majstora, name="lokacije_majstora"),

    #   CHATBOT
    # Prikazuje chatbot i obrađuje korisnička pitanja poslata POST zahtevom.
    path('chatbot/', views.chatbot, name='chatbot'),

]
