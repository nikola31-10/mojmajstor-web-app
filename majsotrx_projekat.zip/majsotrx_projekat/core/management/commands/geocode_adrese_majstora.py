import time

from django.core.management.base import BaseCommand

from core.geocoding import GeocodingServiceError, geocode_address
from core.models import Majstor


class Command(BaseCommand):
    help = "Geokodira adrese postojećih majstora koji nemaju koordinate"

    def handle(self, *args, **options):
        majstori = (
            Majstor.objects
            .filter(korisnik__latitude__isnull=True)
            .select_related("korisnik", "korisnik__idgra")
            .order_by("korisnik_id")
        )

        for majstor in majstori:
            korisnik = majstor.korisnik

            try:
                koordinate = geocode_address(korisnik.adresa, korisnik.idgra.naziv)
            except GeocodingServiceError:
                self.stderr.write(
                    f"Servis nije dostupan; obrada je prekinuta kod ID {korisnik.idkor}."
                )
                break

            if koordinate is None:
                self.stdout.write(
                    self.style.WARNING(
                        f"Adresa nije pronadjena za korisnika ID {korisnik.idkor}."
                    )
                )
            else:
                korisnik.latitude, korisnik.longitude = koordinate
                korisnik.save(update_fields=["latitude", "longitude"])
                self.stdout.write(
                    self.style.SUCCESS(
                        f"{korisnik.idkor}: {korisnik.latitude}, {korisnik.longitude}"
                    )
                )

            # Javni Nominatim dozvoljava najviše jedan zahtev u sekundi.
            time.sleep(1)
