"""
URL configuration for majstorix project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include

urlpatterns = [
    path('admin/doc/', include('django.contrib.admindocs.urls')),
    # Uključuje ugrađeni Django administratorski panel.
    path('admin/', admin.site.urls),
    # Prosleđuje sve aplikacione URL-ove modulu core.urls.
    path('', include('core.urls')),
]

if settings.DEBUG:
    # Tokom razvoja omogućava posluživanje korisnički otpremljenih media fajlova.
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
