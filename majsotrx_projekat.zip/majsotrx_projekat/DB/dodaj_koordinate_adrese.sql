-- Pokrenuti samo ako se Django migracije ne koriste.
-- Migracija core/0003 već izvršava istu izmenu.
ALTER TABLE korisnik
    ADD COLUMN latitude DECIMAL(9,6) NULL,
    ADD COLUMN longitude DECIMAL(9,6) NULL;
