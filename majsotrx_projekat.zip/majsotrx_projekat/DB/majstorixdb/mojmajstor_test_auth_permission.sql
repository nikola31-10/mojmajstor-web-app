-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',3,'add_permission'),(6,'Can change permission',3,'change_permission'),(7,'Can delete permission',3,'delete_permission'),(8,'Can view permission',3,'view_permission'),(9,'Can add group',2,'add_group'),(10,'Can change group',2,'change_group'),(11,'Can delete group',2,'delete_group'),(12,'Can view group',2,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add grad',7,'add_grad'),(26,'Can change grad',7,'change_grad'),(27,'Can delete grad',7,'delete_grad'),(28,'Can view grad',7,'view_grad'),(29,'Can add kategorija',8,'add_kategorija'),(30,'Can change kategorija',8,'change_kategorija'),(31,'Can delete kategorija',8,'delete_kategorija'),(32,'Can view kategorija',8,'view_kategorija'),(33,'Can add ocena',13,'add_ocena'),(34,'Can change ocena',13,'change_ocena'),(35,'Can delete ocena',13,'delete_ocena'),(36,'Can view ocena',13,'view_ocena'),(37,'Can add prijava',16,'add_prijava'),(38,'Can change prijava',16,'change_prijava'),(39,'Can delete prijava',16,'delete_prijava'),(40,'Can view prijava',16,'view_prijava'),(41,'Can add uloga',20,'add_uloga'),(42,'Can change uloga',20,'change_uloga'),(43,'Can delete uloga',20,'delete_uloga'),(44,'Can view uloga',20,'view_uloga'),(45,'Can add zahtev',21,'add_zahtev'),(46,'Can change zahtev',21,'change_zahtev'),(47,'Can delete zahtev',21,'delete_zahtev'),(48,'Can view zahtev',21,'view_zahtev'),(49,'Can add majstor',10,'add_majstor'),(50,'Can change majstor',10,'change_majstor'),(51,'Can delete majstor',10,'delete_majstor'),(52,'Can view majstor',10,'view_majstor'),(53,'Can add korisnik',9,'add_korisnik'),(54,'Can change korisnik',9,'change_korisnik'),(55,'Can delete korisnik',9,'delete_korisnik'),(56,'Can view korisnik',9,'view_korisnik'),(57,'Can add majstor kategorija',11,'add_majstorkategorija'),(58,'Can change majstor kategorija',11,'change_majstorkategorija'),(59,'Can delete majstor kategorija',11,'delete_majstorkategorija'),(60,'Can view majstor kategorija',11,'view_majstorkategorija'),(61,'Can add notifikacija',12,'add_notifikacija'),(62,'Can change notifikacija',12,'change_notifikacija'),(63,'Can delete notifikacija',12,'delete_notifikacija'),(64,'Can view notifikacija',12,'view_notifikacija'),(65,'Can add opstina',14,'add_opstina'),(66,'Can change opstina',14,'change_opstina'),(67,'Can delete opstina',14,'delete_opstina'),(68,'Can view opstina',14,'view_opstina'),(69,'Can add poruka',15,'add_poruka'),(70,'Can change poruka',15,'change_poruka'),(71,'Can delete poruka',15,'delete_poruka'),(72,'Can view poruka',15,'view_poruka'),(73,'Can add prijava problema',17,'add_prijavaproblema'),(74,'Can change prijava problema',17,'change_prijavaproblema'),(75,'Can delete prijava problema',17,'delete_prijavaproblema'),(76,'Can view prijava problema',17,'view_prijavaproblema'),(77,'Can add slika problema',18,'add_slikaproblema'),(78,'Can change slika problema',18,'change_slikaproblema'),(79,'Can delete slika problema',18,'delete_slikaproblema'),(80,'Can view slika problema',18,'view_slikaproblema'),(81,'Can add termin',19,'add_termin'),(82,'Can change termin',19,'change_termin'),(83,'Can delete termin',19,'delete_termin'),(84,'Can view termin',19,'view_termin');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:24
