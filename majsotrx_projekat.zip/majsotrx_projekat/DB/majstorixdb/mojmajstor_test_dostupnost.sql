--
-- Table structure for table `dostupnost`
--

DROP TABLE IF EXISTS `dostupnost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dostupnost` (
  `idDost` int NOT NULL AUTO_INCREMENT,
  `idMajstor` int NOT NULL,
  `datumOd` date NOT NULL,
  `datumDo` date NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`idDost`),
  KEY `idMajstor_idx` (`idMajstor`),
  CONSTRAINT `dostupnost_ibfk_1`
    FOREIGN KEY (`idMajstor`)
    REFERENCES `majstor` (`idMajstor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Dumping data for table `dostupnost`
--

LOCK TABLES `dostupnost` WRITE;
/*!40000 ALTER TABLE `dostupnost` DISABLE KEYS */;
/*!40000 ALTER TABLE `dostupnost` ENABLE KEYS */;
UNLOCK TABLES;