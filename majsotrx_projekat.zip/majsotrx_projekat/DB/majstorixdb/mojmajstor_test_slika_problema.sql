-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `slika_problema`
--

DROP TABLE IF EXISTS `slika_problema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `slika_problema` (
  `idSli` int NOT NULL AUTO_INCREMENT,
  `idZah` int NOT NULL,
  `putanja` varchar(255) NOT NULL,
  PRIMARY KEY (`idSli`),
  KEY `fk_zahtev_slika` (`idZah`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slika_problema`
--

LOCK TABLES `slika_problema` WRITE;
/*!40000 ALTER TABLE `slika_problema` DISABLE KEYS */;
INSERT INTO `slika_problema` VALUES (1,34,'/uploads/problemi/zahtev_34_1.jpg'),(2,38,'/uploads/problemi/zahtev_38_1.jpg'),(3,38,'/uploads/problemi/zahtev_38_2.jpg'),(4,13,'/uploads/problemi/zahtev_13_1.jpg'),(5,13,'/uploads/problemi/zahtev_13_2.jpg'),(6,25,'/uploads/problemi/zahtev_25_1.jpg'),(7,17,'/uploads/problemi/zahtev_17_1.jpg'),(8,15,'/uploads/problemi/zahtev_15_1.jpg'),(9,1,'/uploads/problemi/zahtev_1_1.jpg'),(10,1,'/uploads/problemi/zahtev_1_2.jpg'),(11,40,'/uploads/problemi/zahtev_40_1.jpg'),(12,40,'/uploads/problemi/zahtev_40_2.jpg'),(13,20,'/uploads/problemi/zahtev_20_1.jpg'),(14,35,'/uploads/problemi/zahtev_35_1.jpg'),(15,35,'/uploads/problemi/zahtev_35_2.jpg'),(16,9,'/uploads/problemi/zahtev_9_1.jpg'),(17,11,'/uploads/problemi/zahtev_11_1.jpg'),(18,11,'/uploads/problemi/zahtev_11_2.jpg'),(19,21,'/uploads/problemi/zahtev_21_1.jpg'),(20,21,'/uploads/problemi/zahtev_21_2.jpg'),(21,27,'/uploads/problemi/zahtev_27_1.jpg'),(22,8,'/uploads/problemi/zahtev_8_1.jpg'),(23,8,'/uploads/problemi/zahtev_8_2.jpg'),(24,16,'/uploads/problemi/zahtev_16_1.jpg'),(25,36,'/uploads/problemi/zahtev_36_1.jpg'),(26,36,'/uploads/problemi/zahtev_36_2.jpg'),(27,26,'/uploads/problemi/zahtev_26_1.jpg'),(28,26,'/uploads/problemi/zahtev_26_2.jpg'),(29,18,'/uploads/problemi/zahtev_18_1.jpg'),(30,18,'/uploads/problemi/zahtev_18_2.jpg'),(31,23,'/uploads/problemi/zahtev_23_1.jpg'),(32,23,'/uploads/problemi/zahtev_23_2.jpg');
/*!40000 ALTER TABLE `slika_problema` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:24
