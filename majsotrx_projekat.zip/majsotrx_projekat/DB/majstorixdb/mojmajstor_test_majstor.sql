-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `majstor`
--

DROP TABLE IF EXISTS `majstor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `majstor` (
  `idMajstor` int NOT NULL AUTO_INCREMENT,
  `prosecnaOcena` double NOT NULL DEFAULT '0',
  `opis` text NOT NULL,
  `verifikacija` enum('NA_CEKANJU','VERIFIKOVAN','ODBIJEN') NOT NULL DEFAULT 'NA_CEKANJU',
  `opisVerifikacije` text,
  `razlogOdbijanja` text,
  PRIMARY KEY (`idMajstor`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `majstor`
--

LOCK TABLES `majstor` WRITE;
/*!40000 ALTER TABLE `majstor` DISABLE KEYS */;
INSERT INTO `majstor` VALUES (21,3,'Radim hitne intervencije, popravke i manje adaptacije po dogovoru.','VERIFIKOVAN',NULL,NULL),(22,4,'Precizan rad, korektne cene i garancija na obavljenu uslugu.','VERIFIKOVAN',NULL,NULL),(23,3.67,'Radim hitne intervencije, popravke i manje adaptacije po dogovoru.','VERIFIKOVAN',NULL,NULL),(24,4.6667,'Dostupan za stanove, lokale i kuće, uz prethodnu procenu posla.','VERIFIKOVAN',NULL,NULL),(25,4,'Dostupan za stanove, lokale i kuće, uz prethodnu procenu posla.','ODBIJEN',NULL,'Hakovao klijenta'),(26,0,'Pouzdan majstor sa višegodišnjim iskustvom i brzim izlaskom na teren.','NA_CEKANJU',NULL,''),(27,0,'Pouzdan majstor sa višegodišnjim iskustvom i brzim izlaskom na teren.','NA_CEKANJU',NULL,NULL),(28,0,'Precizan rad, korektne cene i garancija na obavljenu uslugu.','NA_CEKANJU',NULL,''),(29,5,'Precizan rad, korektne cene i garancija na obavljenu uslugu.','VERIFIKOVAN',NULL,NULL),(30,0,'Precizan rad, korektne cene i garancija na obavljenu uslugu.','VERIFIKOVAN',NULL,NULL);
/*!40000 ALTER TABLE `majstor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:25
