-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `zahtev`
--

DROP TABLE IF EXISTS `zahtev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zahtev` (
  `idZah` int NOT NULL AUTO_INCREMENT,
  `idKor` int NOT NULL,
  `idMajstor` int NOT NULL,
  `idKat` int NOT NULL,
  `naslov` varchar(45) NOT NULL,
  `opis` text NOT NULL,
  `napomene` text NOT NULL,
  `adresa` varchar(100) NOT NULL,
  `datum` date NOT NULL DEFAULT (curdate()),
  `status` enum('PRIHVACEN','NA_CEKANJU','ODBIJEN','ZAVRSEN','OTKAZAN') NOT NULL DEFAULT 'NA_CEKANJU',
  PRIMARY KEY (`idZah`),
  KEY `fk_korisnik_zahtev_idx` (`idKor`),
  KEY `fk_majstor_zahtev_idx` (`idMajstor`),
  KEY `fk_kategorija_zahtev_idx` (`idKat`),
  CONSTRAINT `fk_kategorija_zahtev` FOREIGN KEY (`idKat`) REFERENCES `kategorija` (`idKat`),
  CONSTRAINT `fk_korisnik_zahtev` FOREIGN KEY (`idKor`) REFERENCES `korisnik` (`idKor`),
  CONSTRAINT `fk_majstor_zahtev` FOREIGN KEY (`idMajstor`) REFERENCES `majstor` (`idMajstor`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zahtev`
--

LOCK TABLES `zahtev` WRITE;
/*!40000 ALTER TABLE `zahtev` DISABLE KEYS */;
INSERT INTO `zahtev` VALUES (1,9,29,7,'Klima slabo hladi','Potrebna je usluga: klima slabo hladi. Molim majstora da proceni cenu i vreme dolaska.','','Vojvode Stepe 101','2026-05-28','ODBIJEN'),(2,12,23,12,'Popravka šporeta','Potrebna je usluga: popravka šporeta. Molim majstora da proceni cenu i vreme dolaska.','','Cara Dušana 8','2026-05-25','ODBIJEN'),(3,5,21,2,'Nestanak struje u sobi','Potrebna je usluga: nestanak struje u sobi. Molim majstora da proceni cenu i vreme dolaska.','','Hajduk Veljkova 7','2026-05-15','NA_CEKANJU'),(4,10,28,3,'Krečenje dnevne sobe','Potrebna je usluga: krečenje dnevne sobe. Molim majstora da proceni cenu i vreme dolaska.','','Zmaj Jovina 5','2026-05-10','PRIHVACEN'),(5,11,26,10,'Selidba nameštaja','Potrebna je usluga: selidba nameštaja. Molim majstora da proceni cenu i vreme dolaska.','','Kneza Mihaila 12','2026-06-02','OTKAZAN'),(6,18,30,8,'Servis bojlera','Potrebna je usluga: servis bojlera. Molim majstora da proceni cenu i vreme dolaska.','','Bulevar oslobođenja 44','2026-05-26','PRIHVACEN'),(7,13,30,8,'Radijator ne greje','Potrebna je usluga: radijator ne greje. Molim majstora da proceni cenu i vreme dolaska.','','Nemanjina 23','2026-05-13','NA_CEKANJU'),(8,4,22,8,'Servis bojlera','Potrebna je usluga: servis bojlera. Molim majstora da proceni cenu i vreme dolaska.','','Kneza Mihaila 12','2026-06-08','NA_CEKANJU'),(9,18,21,10,'Selidba nameštaja','Potrebna je usluga: selidba nameštaja. Molim majstora da proceni cenu i vreme dolaska.','','Bulevar oslobođenja 44','2026-05-24','ZAVRSEN'),(10,5,29,4,'Keramika za kuhinju','Potrebna je usluga: keramika za kuhinju. Molim majstora da proceni cenu i vreme dolaska.','','Hajduk Veljkova 7','2026-05-17','OTKAZAN'),(11,4,26,6,'Brava se zaglavila','Potrebna je usluga: brava se zaglavila. Molim majstora da proceni cenu i vreme dolaska.','','Takovska 31','2026-06-01','OTKAZAN'),(12,10,27,8,'Radijator ne greje','Potrebna je usluga: radijator ne greje. Molim majstora da proceni cenu i vreme dolaska.','','Zmaj Jovina 5','2026-05-10','NA_CEKANJU'),(13,16,23,12,'Popravka šporeta','Potrebna je usluga: popravka šporeta. Molim majstora da proceni cenu i vreme dolaska.','','Nemanjina 23','2026-05-11','ZAVRSEN'),(14,5,30,9,'Popravka oštećenog parketa','Potrebna je usluga: popravka oštećenog parketa. Molim majstora da proceni cenu i vreme dolaska.','','Dositejeva 14','2026-06-04','ODBIJEN'),(15,9,22,5,'Štelovanje sobnih vrata','Potrebna je usluga: štelovanje sobnih vrata. Molim majstora da proceni cenu i vreme dolaska.','','Zmaj Jovina 5','2026-05-24','ODBIJEN'),(16,8,29,4,'Keramika za kuhinju','Potrebna je usluga: keramika za kuhinju. Molim majstora da proceni cenu i vreme dolaska.','','Kralja Petra 19','2026-05-13','ZAVRSEN'),(17,7,21,12,'Popravka šporeta','Potrebna je usluga: popravka šporeta. Molim majstora da proceni cenu i vreme dolaska.','','Kneza Mihaila 12','2026-06-01','PRIHVACEN'),(18,16,25,1,'Zamena slavine','Potrebna je usluga: zamena slavine. Molim majstora da proceni cenu i vreme dolaska.','','Zmaj Jovina 5','2026-05-13','ZAVRSEN'),(19,12,30,8,'Servis bojlera','Potrebna je usluga: servis bojlera. Molim majstora da proceni cenu i vreme dolaska.','','Nemanjina 23','2026-05-06','NA_CEKANJU'),(20,11,22,8,'Radijator ne greje','Potrebna je usluga: radijator ne greje. Molim majstora da proceni cenu i vreme dolaska.','','Hajduk Veljkova 7','2026-05-31','ZAVRSEN'),(21,12,27,1,'Problem sa vodokotlićem','Potrebna je usluga: problem sa vodokotlićem. Molim majstora da proceni cenu i vreme dolaska.','','Bulevar oslobođenja 44','2026-05-06','ODBIJEN'),(22,7,29,7,'Servis klime','Potrebna je usluga: servis klime. Molim majstora da proceni cenu i vreme dolaska.','','Zmaj Jovina 5','2026-05-12','PRIHVACEN'),(23,15,23,2,'Zamena utičnica','Potrebna je usluga: zamena utičnica. Molim majstora da proceni cenu i vreme dolaska.','','Cara Dušana 8','2026-05-06','ZAVRSEN'),(24,5,24,3,'Gletovanje hodnika','Potrebna je usluga: gletovanje hodnika. Molim majstora da proceni cenu i vreme dolaska.','','Cara Dušana 8','2026-05-30','ZAVRSEN'),(25,16,26,10,'Pakovanje i nošenje kutija','Potrebna je usluga: pakovanje i nošenje kutija. Molim majstora da proceni cenu i vreme dolaska.','','Dositejeva 14','2026-05-23','NA_CEKANJU'),(26,1,24,3,'Gletovanje hodnika','Potrebna je usluga: gletovanje hodnika. Molim majstora da proceni cenu i vreme dolaska.','','Cara Dušana 8','2026-05-07','ZAVRSEN'),(27,7,25,7,'Klima slabo hladi','Potrebna je usluga: klima slabo hladi. Molim majstora da proceni cenu i vreme dolaska.','','Dositejeva 14','2026-05-17','NA_CEKANJU'),(28,9,29,4,'Keramika za kuhinju','Potrebna je usluga: keramika za kuhinju. Molim majstora da proceni cenu i vreme dolaska.','','Kneza Mihaila 12','2026-05-27','ODBIJEN'),(29,15,23,12,'Popravka šporeta','Potrebna je usluga: popravka šporeta. Molim majstora da proceni cenu i vreme dolaska.','','Dositejeva 14','2026-06-07','PRIHVACEN'),(30,5,29,7,'Montaža unutrašnje jedinice','Potrebna je usluga: montaža unutrašnje jedinice. Molim majstora da proceni cenu i vreme dolaska.','','Kneza Mihaila 12','2026-05-10','ZAVRSEN'),(31,20,22,8,'Radijator ne greje','Potrebna je usluga: radijator ne greje. Molim majstora da proceni cenu i vreme dolaska.','','Takovska 31','2026-05-10','NA_CEKANJU'),(32,4,26,10,'Pakovanje i nošenje kutija','Potrebna je usluga: pakovanje i nošenje kutija. Molim majstora da proceni cenu i vreme dolaska.','','Dositejeva 14','2026-05-04','PRIHVACEN'),(33,4,30,9,'Popravka oštećenog parketa','Potrebna je usluga: popravka oštećenog parketa. Molim majstora da proceni cenu i vreme dolaska.','','Vojvode Stepe 101','2026-05-04','PRIHVACEN'),(34,17,22,1,'Zamena slavine','Potrebna je usluga: zamena slavine. Molim majstora da proceni cenu i vreme dolaska.','','Bulevar oslobođenja 44','2026-06-05','NA_CEKANJU'),(35,20,24,8,'Provera instalacija grejanja','Potrebna je usluga: provera instalacija grejanja. Molim majstora da proceni cenu i vreme dolaska.','','Vojvode Stepe 101','2026-06-08','ZAVRSEN'),(36,18,29,8,'Servis bojlera','Potrebna je usluga: servis bojlera. Molim majstora da proceni cenu i vreme dolaska.','','Dositejeva 14','2026-06-02','OTKAZAN'),(37,7,28,5,'Izrada police','Potrebna je usluga: izrada police. Molim majstora da proceni cenu i vreme dolaska.','','Kralja Petra 19','2026-05-09','PRIHVACEN'),(38,3,24,8,'Provera instalacija grejanja','Potrebna je usluga: provera instalacija grejanja. Molim majstora da proceni cenu i vreme dolaska.','','Nemanjina 23','2026-05-16','PRIHVACEN'),(39,4,24,11,'Generalno čišćenje stana','Potrebna je usluga: generalno čišćenje stana. Molim majstora da proceni cenu i vreme dolaska.','','Cara Dušana 8','2026-05-24','NA_CEKANJU'),(40,4,22,8,'Servis bojlera','Potrebna je usluga: servis bojlera. Molim majstora da proceni cenu i vreme dolaska.','','Nemanjina 23','2026-06-01','NA_CEKANJU'),(41,32,22,1,'Proba','j','','Булевар краља Александра 73, Београд','2026-07-11','NA_CEKANJU'),(42,32,22,1,'Proba','j','','Булевар краља Александра 73, Београд','2026-07-11','NA_CEKANJU'),(43,32,22,1,'Proba','j','','Булевар краља Александра 73, Београд','2026-07-11','NA_CEKANJU'),(44,32,22,1,'Proba','j','','Булевар краља Александра 73, Београд','2026-07-11','NA_CEKANJU');
/*!40000 ALTER TABLE `zahtev` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:23
