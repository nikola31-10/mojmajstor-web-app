-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prijava_problema`
--

DROP TABLE IF EXISTS `prijava_problema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prijava_problema` (
  `idPri` int NOT NULL AUTO_INCREMENT,
  `idKor` int NOT NULL,
  `idZah` int NOT NULL,
  `opis` text NOT NULL,
  `status` enum('POSLATA','RESENA','ODBIJENA') NOT NULL DEFAULT 'POSLATA',
  PRIMARY KEY (`idPri`),
  KEY `fk_korisnik_prijava_idx` (`idKor`),
  KEY `fk_zahtev_prijava` (`idZah`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prijava_problema`
--

LOCK TABLES `prijava_problema` WRITE;
/*!40000 ALTER TABLE `prijava_problema` DISABLE KEYS */;
INSERT INTO `prijava_problema` VALUES (1,13,7,'Majstor se nije pojavio u zakazanom terminu.','POSLATA'),(2,9,15,'Cena nije bila ista kao dogovorena.','POSLATA'),(3,5,10,'Majstor se nije pojavio u zakazanom terminu.','ODBIJENA'),(4,3,38,'Korisnik je otkazao bez obrazloženja.','POSLATA'),(5,17,34,'Korisnik je otkazao bez obrazloženja.','ODBIJENA'),(6,4,40,'Neprimerena komunikacija u porukama.','ODBIJENA'),(7,5,30,'Majstor se nije pojavio u zakazanom terminu.','POSLATA'),(8,18,6,'Majstor se nije pojavio u zakazanom terminu.','RESENA'),(9,5,30,'nema dozvoljenih termina','POSLATA');
/*!40000 ALTER TABLE `prijava_problema` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:23
