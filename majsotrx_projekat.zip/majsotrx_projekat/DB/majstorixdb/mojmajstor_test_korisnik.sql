-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `korisnik`
--

DROP TABLE IF EXISTS `korisnik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `korisnik` (
  `idKor` int NOT NULL AUTO_INCREMENT,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `lozinka` varchar(45) NOT NULL,
  `telefon` varchar(45) NOT NULL,
  `adresa` varchar(45) NOT NULL,
  `idGra` int NOT NULL,
  `idUlo` int NOT NULL,
  `status` enum('AKTIVAN','BLOKIRAN','DEAKTIVIRAN') NOT NULL DEFAULT 'AKTIVAN',
  `razlogBlokiranja` text,
  `latitude` decimal(9,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  PRIMARY KEY (`idKor`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `idGra_idx` (`idGra`),
  KEY `idUlo_idx` (`idUlo`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `korisnik`
--

LOCK TABLES `korisnik` WRITE;
/*!40000 ALTER TABLE `korisnik` DISABLE KEYS */;
INSERT INTO `korisnik` VALUES (1,'Miloš','Đorđević','korisnik1@mail.com','korisnik1','1234','066433012','Bulevar oslobođenja 44',3,1,'AKTIVAN',NULL,NULL,NULL),(2,'Aleksa','Lazarević','korisnik2@mail.com','korisnik2','1234','067624039','Cara Dušana 8',1,1,'AKTIVAN',NULL,NULL,NULL),(3,'Milan','Jovanović','korisnik3@mail.com','korisnik3','1234','062215279','Nemanjina 23',2,1,'AKTIVAN',NULL,NULL,NULL),(4,'Jelena','Đorđević','korisnik4@mail.com','korisnik4','1234','067135241','Vojvode Stepe 101',1,1,'AKTIVAN',NULL,NULL,NULL),(5,'Teodora','Lazarević','korisnik5@mail.com','korisnik5','1234','069513358','Zmaj Jovina 5',4,1,'AKTIVAN',NULL,NULL,NULL),(6,'Tamara','Jovanović','korisnik6@mail.com','korisnik6','1234','061629072','Kralja Petra 19',2,1,'AKTIVAN',NULL,NULL,NULL),(7,'Nikola','Đorđević','korisnik7@mail.com','korisnik7','1234','068275367','Takovska 31',7,1,'AKTIVAN',NULL,NULL,NULL),(8,'Stefan','Lazarević','korisnik8@mail.com','korisnik8','1234','062171979','Dositejeva 14',4,1,'AKTIVAN',NULL,NULL,NULL),(9,'Luka','Jovanović','korisnik9@mail.com','korisnik9','1234','062521911','Hajduk Veljkova 7',7,1,'AKTIVAN',NULL,NULL,NULL),(10,'Ana','Đorđević','korisnik10@mail.com','korisnik10','1234','061991709','Kneza Mihaila 12',2,1,'AKTIVAN',NULL,NULL,NULL),(11,'Ivana','Lazarević','korisnik11@mail.com','korisnik11','1234','064745328','Bulevar oslobođenja 44',1,1,'AKTIVAN',NULL,NULL,NULL),(12,'Sara','Jovanović','korisnik12@mail.com','korisnik12','1234','067655194','Cara Dušana 8',1,1,'AKTIVAN',NULL,NULL,NULL),(13,'Nevena','Đorđević','korisnik13@mail.com','korisnik13','1234','064709137','Nemanjina 23',1,1,'AKTIVAN',NULL,NULL,NULL),(14,'Petar','Lazarević','korisnik14@mail.com','korisnik14','1234','063234302','Vojvode Stepe 101',5,1,'AKTIVAN',NULL,NULL,NULL),(15,'Jovan','Jovanović','korisnik15@mail.com','korisnik15','1234','068031986','Zmaj Jovina 5',3,1,'AKTIVAN',NULL,NULL,NULL),(16,'Vladimir','Đorđević','korisnik16@mail.com','korisnik16','1234','062976225','Kralja Petra 19',5,1,'AKTIVAN',NULL,NULL,NULL),(17,'Milica','Lazarević','korisnik17@mail.com','korisnik17','1234','064032085','Takovska 31',2,1,'AKTIVAN',NULL,NULL,NULL),(18,'Marija','Jovanović','korisnik18@mail.com','korisnik18','1234','064151952','Dositejeva 14',6,1,'BLOKIRAN',NULL,NULL,NULL),(19,'Katarina','Đorđević','korisnik19@mail.com','korisnik19','1234','062634613','Hajduk Veljkova 7',2,1,'AKTIVAN',NULL,NULL,NULL),(20,'Marko','Lazarević','korisnik20@mail.com','korisnik20','1234','061999941','Kneza Mihaila 12',4,1,'AKTIVAN',NULL,NULL,NULL),(21,'Stefan','Tomić','majstor1@mail.com','majstor1','1234','069328453','Bulevar oslobođenja 44',7,2,'AKTIVAN',NULL,NULL,NULL),(22,'Vladimir','Stojanović','majstor2@mail.com','majstor2','1234','066270514','Cara Dušana 8',8,2,'AKTIVAN',NULL,45.195668,20.321642),(23,'Jelena','Vuković','majstor3@mail.com','majstor3','1234','068603172','Nemanjina 23',6,2,'BLOKIRAN',NULL,43.886543,20.346547),(24,'Sara','Ilić','majstor4@mail.com','majstor4','1234','066029255','Vojvode Stepe 101',4,2,'AKTIVAN',NULL,44.006592,20.922549),(25,'Marko','Lazarević','majstor5@mail.com','majstor5','1234','064015985','Zmaj Jovina 5',4,2,'AKTIVAN',NULL,44.017535,20.918161),(26,'Stefan','Nikolić','majstor6@mail.com','majstor6','1234','062373299','Kralja Petra 19',5,2,'BLOKIRAN',NULL,43.751995,20.700395),(27,'Vladimir','Kostić','majstor7@mail.com','majstor7','1234','069811335','Takovska 31',8,2,'AKTIVAN',NULL,45.387484,20.392906),(28,'Jelena','Petrović','majstor8@mail.com','majstor8','1234','066762565','Dositejeva 14',8,2,'AKTIVAN',NULL,45.236336,20.574672),(29,'Sara','Milić','majstor9@mail.com','majstor9','1234','065830794','Hajduk Veljkova 7',2,2,'AKTIVAN',NULL,45.253731,19.822131),(30,'Marko','Jovanović','majstor10@mail.com','majstor10','1234','062980815','Kneza Mihaila 12',7,2,'AKTIVAN',NULL,NULL,NULL),(31,'Admin','Majstorix','admin@majstorix.rs','admin','admin','060000000','Administratorska 1',1,3,'AKTIVAN',NULL,NULL,NULL),(32,'djordje','igic','id@gmail','userdjordje','sifradjordje','123','a',1,1,'AKTIVAN',NULL,NULL,NULL);
/*!40000 ALTER TABLE `korisnik` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-13 14:20:06
