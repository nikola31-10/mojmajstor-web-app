-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notifikacija`
--

DROP TABLE IF EXISTS `notifikacija`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifikacija` (
  `idNot` int NOT NULL AUTO_INCREMENT,
  `idKor` int NOT NULL,
  `idZahtev` int DEFAULT NULL,
  `tekst` text NOT NULL,
  `procitana` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`idNot`),
  KEY `fk_korisnik_notifikacija_idx` (`idKor`),
  KEY `fk_zahtev_notifikacija_idx` (`idZahtev`),
  CONSTRAINT `fk_korisnik_notifikacija` FOREIGN KEY (`idKor`) REFERENCES `korisnik` (`idKor`),
  CONSTRAINT `fk_zahtev_notifikacija` FOREIGN KEY (`idZahtev`) REFERENCES `zahtev` (`idZah`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifikacija`
--

LOCK TABLES `notifikacija` WRITE;
/*!40000 ALTER TABLE `notifikacija` DISABLE KEYS */;
INSERT INTO `notifikacija` VALUES (1,1,NULL,'Ocena je uspešno evidentirana.',1),(2,1,NULL,'Imate novu poruku u zahtevu.',0),(3,2,NULL,'Imate novu poruku u zahtevu.',1),(4,2,NULL,'Ocena je uspešno evidentirana.',1),(5,3,NULL,'Dodat je novi termin za intervenciju.',0),(6,3,NULL,'Ocena je uspešno evidentirana.',1),(7,4,NULL,'Ocena je uspešno evidentirana.',1),(8,4,NULL,'Imate novu poruku u zahtevu.',1),(9,5,NULL,'Imate novu poruku u zahtevu.',1),(10,5,NULL,'Dodat je novi termin za intervenciju.',1),(11,6,NULL,'Imate novu poruku u zahtevu.',0),(12,6,NULL,'Imate novu poruku u zahtevu.',1),(13,7,NULL,'Dodat je novi termin za intervenciju.',1),(14,7,NULL,'Imate novu poruku u zahtevu.',1),(15,8,NULL,'Ocena je uspešno evidentirana.',0),(16,8,NULL,'Dodat je novi termin za intervenciju.',1),(17,9,NULL,'Dodat je novi termin za intervenciju.',0),(18,9,NULL,'Dodat je novi termin za intervenciju.',0),(19,10,NULL,'Imate novu poruku u zahtevu.',1),(20,10,NULL,'Status zahteva je promenjen.',0),(21,11,39,'Dodat je novi termin za intervenciju.',1),(22,11,39,'Dodat je novi termin za intervenciju.',0),(23,12,NULL,'Dodat je novi termin za intervenciju.',1),(24,12,NULL,'Imate novu poruku u zahtevu.',1),(25,13,NULL,'Status zahteva je promenjen.',0),(26,13,NULL,'Imate novu poruku u zahtevu.',1),(27,14,NULL,'Ocena je uspešno evidentirana.',0),(28,14,NULL,'Dodat je novi termin za intervenciju.',1),(29,15,NULL,'Imate novu poruku u zahtevu.',0),(30,15,NULL,'Status zahteva je promenjen.',1),(31,16,NULL,'Ocena je uspešno evidentirana.',1),(32,16,NULL,'Dodat je novi termin za intervenciju.',1),(33,17,NULL,'Dodat je novi termin za intervenciju.',1),(34,17,NULL,'Ocena je uspešno evidentirana.',0),(35,18,NULL,'Dodat je novi termin za intervenciju.',1),(36,18,NULL,'Ocena je uspešno evidentirana.',0),(37,19,NULL,'Status zahteva je promenjen.',0),(38,19,NULL,'Imate novu poruku u zahtevu.',0),(39,20,NULL,'Ocena je uspešno evidentirana.',0),(40,20,NULL,'Ocena je uspešno evidentirana.',1),(41,21,3,'Ocena je uspešno evidentirana.',1),(42,21,9,'Status zahteva je promenjen.',0),(43,22,8,'Status zahteva je promenjen.',0),(44,22,15,'Status zahteva je promenjen.',1),(45,23,2,'Imate novu poruku u zahtevu.',1),(46,23,13,'Status zahteva je promenjen.',1),(47,24,24,'Dodat je novi termin za intervenciju.',0),(48,24,26,'Imate novu poruku u zahtevu.',1),(49,25,18,'Ocena je uspešno evidentirana.',1),(50,25,27,'Status zahteva je promenjen.',1),(51,26,5,'Dodat je novi termin za intervenciju.',1),(52,26,11,'Imate novu poruku u zahtevu.',1),(53,27,12,'Dodat je novi termin za intervenciju.',1),(54,27,21,'Status zahteva je promenjen.',0),(55,28,4,'Imate novu poruku u zahtevu.',1),(56,28,37,'Status zahteva je promenjen.',1),(57,29,1,'Ocena je uspešno evidentirana.',1),(58,29,10,'Ocena je uspešno evidentirana.',1),(59,30,6,'Imate novu poruku u zahtevu.',0),(60,30,7,'Imate novu poruku u zahtevu.',1),(61,31,NULL,'Ocena je uspešno evidentirana.',1),(62,31,NULL,'Imate novu poruku u zahtevu.',0),(63,31,NULL,'Ocena je uspešno evidentirana.',1),(64,31,NULL,'Ocena je uspešno evidentirana.',0);
/*!40000 ALTER TABLE `notifikacija` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:25
