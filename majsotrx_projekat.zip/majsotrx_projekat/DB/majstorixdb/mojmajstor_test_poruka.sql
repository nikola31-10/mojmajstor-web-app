-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: mojmajstor_test
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `poruka`
--

DROP TABLE IF EXISTS `poruka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `poruka` (
  `idPor` int NOT NULL AUTO_INCREMENT,
  `idZah` int NOT NULL,
  `idPosiljalac` int NOT NULL,
  `tekst` text NOT NULL,
  `vreme` time NOT NULL DEFAULT (curtime()),
  `idPrimalac` int NOT NULL,
  `procitano` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idPor`),
  KEY `fk_korisnik_poruka_idx` (`idPosiljalac`),
  KEY `fk_primalac_poruka_idx` (`idPrimalac`),
  KEY `fk_zahtev_poruka` (`idZah`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poruka`
--

LOCK TABLES `poruka` WRITE;
/*!40000 ALTER TABLE `poruka` DISABLE KEYS */;
INSERT INTO `poruka` VALUES (1,1,9,'Poštovanje, da li možete da pogledate zahtev za: Klima slabo hladi?','12:00:00',29,0),(2,1,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','14:00:00',9,1),(3,2,12,'Poštovanje, da li možete da pogledate zahtev za: Popravka šporeta?','08:00:00',23,1),(4,2,23,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','09:15:00',12,0),(5,3,5,'Poštovanje, da li možete da pogledate zahtev za: Nestanak struje u sobi?','12:00:00',21,1),(6,4,10,'Poštovanje, da li možete da pogledate zahtev za: Krečenje dnevne sobe?','08:30:00',28,1),(7,4,28,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','12:15:00',10,0),(8,5,11,'Poštovanje, da li možete da pogledate zahtev za: Selidba nameštaja?','16:15:00',26,0),(9,5,26,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','10:30:00',11,0),(10,6,18,'Poštovanje, da li možete da pogledate zahtev za: Servis bojlera?','10:15:00',30,1),(11,6,30,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','18:30:00',18,0),(12,7,13,'Poštovanje, da li možete da pogledate zahtev za: Radijator ne greje?','12:45:00',30,0),(13,8,4,'Poštovanje, da li možete da pogledate zahtev za: Servis bojlera?','12:30:00',22,0),(14,9,18,'Poštovanje, da li možete da pogledate zahtev za: Selidba nameštaja?','12:00:00',21,0),(15,9,21,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','08:15:00',18,1),(16,10,5,'Poštovanje, da li možete da pogledate zahtev za: Keramika za kuhinju?','11:45:00',29,0),(17,10,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','18:45:00',5,1),(18,11,4,'Poštovanje, da li možete da pogledate zahtev za: Brava se zaglavila?','16:45:00',26,1),(19,11,26,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','19:15:00',4,0),(20,12,10,'Poštovanje, da li možete da pogledate zahtev za: Radijator ne greje?','13:15:00',27,0),(21,13,16,'Poštovanje, da li možete da pogledate zahtev za: Popravka šporeta?','14:30:00',23,0),(22,13,23,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','10:00:00',16,0),(23,14,5,'Poštovanje, da li možete da pogledate zahtev za: Popravka oštećenog parketa?','18:30:00',30,1),(24,14,30,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','10:00:00',5,0),(25,15,9,'Poštovanje, da li možete da pogledate zahtev za: Štelovanje sobnih vrata?','18:45:00',22,1),(26,15,22,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','17:15:00',9,1),(27,16,8,'Poštovanje, da li možete da pogledate zahtev za: Keramika za kuhinju?','08:45:00',29,0),(28,16,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','10:30:00',8,1),(29,17,7,'Poštovanje, da li možete da pogledate zahtev za: Popravka šporeta?','08:30:00',21,1),(30,17,21,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','13:30:00',7,0),(31,18,16,'Poštovanje, da li možete da pogledate zahtev za: Zamena slavine?','08:30:00',25,0),(32,18,25,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','13:15:00',16,0),(33,19,12,'Poštovanje, da li možete da pogledate zahtev za: Servis bojlera?','13:45:00',30,0),(34,20,11,'Poštovanje, da li možete da pogledate zahtev za: Radijator ne greje?','15:30:00',22,0),(35,20,22,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','11:00:00',11,0),(36,21,12,'Poštovanje, da li možete da pogledate zahtev za: Problem sa vodokotlićem?','12:00:00',27,0),(37,21,27,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','14:00:00',12,1),(38,22,7,'Poštovanje, da li možete da pogledate zahtev za: Servis klime?','08:30:00',29,1),(39,22,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','18:15:00',7,0),(40,23,15,'Poštovanje, da li možete da pogledate zahtev za: Zamena utičnica?','17:15:00',23,1),(41,23,23,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','20:30:00',15,1),(42,24,5,'Poštovanje, da li možete da pogledate zahtev za: Gletovanje hodnika?','10:30:00',24,0),(43,24,24,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','08:45:00',5,0),(44,25,16,'Poštovanje, da li možete da pogledate zahtev za: Pakovanje i nošenje kutija?','16:00:00',26,0),(45,26,1,'Poštovanje, da li možete da pogledate zahtev za: Gletovanje hodnika?','09:00:00',24,0),(46,26,24,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','10:30:00',1,0),(47,27,7,'Poštovanje, da li možete da pogledate zahtev za: Klima slabo hladi?','14:45:00',25,0),(48,28,9,'Poštovanje, da li možete da pogledate zahtev za: Keramika za kuhinju?','18:00:00',29,0),(49,28,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','15:30:00',9,0),(50,29,15,'Poštovanje, da li možete da pogledate zahtev za: Popravka šporeta?','15:00:00',23,0),(51,29,23,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','18:00:00',15,1),(52,30,5,'Poštovanje, da li možete da pogledate zahtev za: Montaža unutrašnje jedinice?','12:00:00',29,1),(53,30,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','11:15:00',5,0),(54,31,20,'Poštovanje, da li možete da pogledate zahtev za: Radijator ne greje?','19:45:00',22,1),(55,32,4,'Poštovanje, da li možete da pogledate zahtev za: Pakovanje i nošenje kutija?','14:00:00',26,1),(56,32,26,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','18:30:00',4,0),(57,33,4,'Poštovanje, da li možete da pogledate zahtev za: Popravka oštećenog parketa?','17:15:00',30,0),(58,33,30,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','17:15:00',4,1),(59,34,17,'Poštovanje, da li možete da pogledate zahtev za: Zamena slavine?','12:30:00',22,0),(60,35,20,'Poštovanje, da li možete da pogledate zahtev za: Provera instalacija grejanja?','08:45:00',24,0),(61,35,24,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','15:30:00',20,0),(62,36,18,'Poštovanje, da li možete da pogledate zahtev za: Servis bojlera?','19:15:00',29,1),(63,36,29,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','12:30:00',18,1),(64,37,7,'Poštovanje, da li možete da pogledate zahtev za: Izrada police?','15:45:00',28,0),(65,37,28,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','16:15:00',7,1),(66,38,3,'Poštovanje, da li možete da pogledate zahtev za: Provera instalacija grejanja?','09:45:00',24,0),(67,38,24,'Pozdrav, mogu da izađem na teren. Poslaću termin i okvirnu cenu.','12:45:00',3,0),(68,39,4,'Poštovanje, da li možete da pogledate zahtev za: Generalno čišćenje stana?','16:45:00',24,1),(69,40,4,'Poštovanje, da li možete da pogledate zahtev za: Servis bojlera?','14:15:00',22,0),(70,2,23,'adfs','20:47:16',12,0);
/*!40000 ALTER TABLE `poruka` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-11 23:25:23
